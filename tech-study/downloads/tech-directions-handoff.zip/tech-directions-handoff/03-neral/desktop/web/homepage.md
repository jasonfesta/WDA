# Neral — Desktop web homepage

## Recreation prompt

Recreate a refined desktop web homepage for **Neral**, 1536 × 3072 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Model evaluation and human review for AI product teams. Core flow: compare paired cases, inspect regressions, record human judgments and sign off.

**Palette and visual character:** Neutral charcoal #1C1B18, warm ivory #EEEAE1, muted amber #B28B4D, quiet gray. No purple, blue-gray or neon. All panels use subtle neutral tonal separation. Layered translucent rectangular evidence films, fine ordered case grid and one muted amber outlined region, precise diagonal depth only in marketing hero. Carry fine amber rules into flat product UI.

**Typography:** Inter 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Inter](https://fonts.google.com/specimen/Inter), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Open with offset translucent evidence films on the left and a restrained headline on the right. A narrow metrics strip introduces the comparison. Continue with a large dark baseline/candidate review preview, three short method blocks, a clear final invitation with an evidence-film detail, signup and complete footer. Neutral charcoal stays consistent throughout; use muted amber for differences and active details. Headline: “See what the score hides.” Supporting copy: “Compare model behavior, find the regressions, and give every release a human judgment.” Primary action: “Explore an evaluation”. Product section heading: “A better average isn’t the whole story.”. Benefits: Pair the cases. / Examine the difference. / Record the judgment. Closing headline: “Give every model a proper review.”. Footer includes the brand, contextual product/resource links, Product notes signup, © 2026 Neral, Privacy and Terms. Keep the full page from navigation through footer.

**Persistent sample state:**

```json
{
  "evaluation": "EV-024",
  "title": "Support answers",
  "pairedCases": 120,
  "baselinePassed": 96,
  "candidatePassed": 108,
  "baselinePercent": 80,
  "candidatePercent": 90,
  "percentagePointChange": 10,
  "regressions": 6,
  "signed": [
    "Asha Ng",
    "Leo Ruiz"
  ],
  "pending": "Mina Shah",
  "case043": {
    "baseline": "Returns within 30 days, except final-sale items.",
    "candidate": "Returns within 30 days.",
    "issue": "Exception omitted"
  }
}
```

Case 043 is Return policy. Baseline: “Returns within 30 days, except final-sale items.” Candidate: “Returns within 30 days.” Issue: Exception omitted; human review required. Do not mark this regression approved.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Devin](https://devin.ai/) — Mature software presentation and technical focus.
- [Duna](https://duna.com/) — A recognizable art direction carried through a technology site; retain Neral’s original evidence-film graphic.
- [Braintrust experiment comparison](https://www.braintrust.dev/foundations/comparing-experiments) — Per-case comparison of outputs and scores, beyond an aggregate average.
