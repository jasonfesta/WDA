# Neral — iOS application

## Recreation prompt

Recreate a refined ios application for **Neral**, 874 × 1800 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Model evaluation and human review for AI product teams. Core flow: compare paired cases, inspect regressions, record human judgments and sign off.

**Palette and visual character:** Neutral charcoal #1C1B18, warm ivory #EEEAE1, muted amber #B28B4D, quiet gray. No purple, blue-gray or neon. All panels use subtle neutral tonal separation. Layered translucent rectangular evidence films, fine ordered case grid and one muted amber outlined region, precise diagonal depth only in marketing hero. Carry fine amber rules into flat product UI.

**Typography:** Inter 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Inter](https://fonts.google.com/specimen/Inter), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** A complete upright phone screen from status bar at 9:41 through the bottom tab bar and home indicator. Square outer canvas, full bleed, no device frame. This screen is human review of Case 043. Review detail for Case 043. Stack clear Baseline and Candidate response blocks vertically at phone width, with the exact final-sale exception emphasized only in the baseline. A restrained amber Exception omitted tag. Context row EV-024 / Support answers, progress 043 of 120, button Add review. Below give compact 2 of 3 reviewers signed. No fake chart or lorem ipsum. Bottom tabs in order: Evaluations, Reviews, Account. Only Reviews is selected. Back navigation remains under that parent destination. Keep practical touch sizes and all controls fully visible. Do not use a marketing hero layout.

**Persistent sample state:**

```json
{
  "evaluation": "EV-024",
  "title": "Support answers",
  "pairedCases": 120,
  "baselinePassed": 96,
  "candidatePassed": 108,
  "baselinePercent": 80,
  "candidatePercent": 90,
  "percentagePointChange": 10,
  "regressions": 6,
  "signed": [
    "Asha Ng",
    "Leo Ruiz"
  ],
  "pending": "Mina Shah",
  "case043": {
    "baseline": "Returns within 30 days, except final-sale items.",
    "candidate": "Returns within 30 days.",
    "issue": "Exception omitted"
  }
}
```

Case 043 is Return policy. Baseline: “Returns within 30 days, except final-sale items.” Candidate: “Returns within 30 days.” Issue: Exception omitted; human review required. Do not mark this regression approved.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Devin](https://devin.ai/) — Mature software presentation and technical focus.
- [Duna](https://duna.com/) — A recognizable art direction carried through a technology site; retain Neral’s original evidence-film graphic.
- [Braintrust experiment comparison](https://www.braintrust.dev/foundations/comparing-experiments) — Per-case comparison of outputs and scores, beyond an aggregate average.
