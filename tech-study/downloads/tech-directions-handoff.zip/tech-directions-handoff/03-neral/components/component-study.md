# Neral — Product components

## Recreation prompt

Recreate a refined product components for **Neral**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Model evaluation and human review for AI product teams. Core flow: compare paired cases, inspect regressions, record human judgments and sign off.

**Palette and visual character:** Neutral charcoal #1C1B18, warm ivory #EEEAE1, muted amber #B28B4D, quiet gray. No purple, blue-gray or neon. All panels use subtle neutral tonal separation. Layered translucent rectangular evidence films, fine ordered case grid and one muted amber outlined region, precise diagonal depth only in marketing hero. Carry fine amber rules into flat product UI.

**Typography:** Inter 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Inter](https://fonts.google.com/specimen/Inter), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** One spacious baseline/candidate comparison card using exact two answers and the Exception omitted tag. Beside it a human review card with 2/3 signed and the three reviewers. Add review action. Precise neutral dark UI with warm amber rules; leave wide breathing room. Keep components complete and at natural proportions with generous surrounding space; show only interface content, with no external presentation labels. The case label reads Case 043 · 1 of 6 regressions. Keep the reviewer card at right and the response comparison at left, with the aggregate summary above.

**Persistent sample state:**

```json
{
  "evaluation": "EV-024",
  "title": "Support answers",
  "pairedCases": 120,
  "baselinePassed": 96,
  "candidatePassed": 108,
  "baselinePercent": 80,
  "candidatePercent": 90,
  "percentagePointChange": 10,
  "regressions": 6,
  "signed": [
    "Asha Ng",
    "Leo Ruiz"
  ],
  "pending": "Mina Shah",
  "case043": {
    "baseline": "Returns within 30 days, except final-sale items.",
    "candidate": "Returns within 30 days.",
    "issue": "Exception omitted"
  }
}
```

Case 043 is Return policy. Baseline: “Returns within 30 days, except final-sale items.” Candidate: “Returns within 30 days.” Issue: Exception omitted; human review required. Do not mark this regression approved.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Devin](https://devin.ai/) — Mature software presentation and technical focus.
- [Duna](https://duna.com/) — A recognizable art direction carried through a technology site; retain Neral’s original evidence-film graphic.
- [Braintrust experiment comparison](https://www.braintrust.dev/foundations/comparing-experiments) — Per-case comparison of outputs and scores, beyond an aggregate average.
