# Kivo — Desktop web homepage

## Recreation prompt

Recreate a refined desktop web homepage for **Kivo**, 1536 × 3072 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Internal request routing and approvals for operations teams. Core flow: submit a request, assign an owner, review and complete the handoff.

**Palette and visual character:** Muted sunflower #E8CB55, cream #F7F2E6, black #1D1D18 and brick red #CF5B3B. Confident flat blocks and rules, no glossy gradients. Original arrow assembled from tiny repeated characters and pixels, with grid-like density and a sharp 90-degree bend. Bold graphic hierarchy, rigid dividers, warm colors. Use yellow for navigation/status accents, cream for readable app work areas.

**Typography:** Space Grotesk 400/500/600/700, IBM Plex Mono 400/500 for route metadata. Use naturally proportioned lettering, clear functional text and generous spacing. [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk), weights 400, 500, 600, 700; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Open on muted sunflower yellow with large black typography and an original character-built routing arrow. Show a narrow three-stage example route. Continue on cream with a three-row request queue, three short route/owner/record benefits, a compact routing-template section, a brick-red conversion block with an arrow, newsletter signup and full footer. Use sturdy rules and flat blocks rather than 3D effects. Headline: “Less waiting. More moving.” Supporting copy: “Give every request a clear route, a named owner and a next step.” Primary action: “Build a route”. Product section heading: “Work has a route. Everyone can see it.”. Benefits: A route for every request. / An owner at every step. / A record you can follow. Closing headline: “Give work somewhere to go.”. Footer includes the brand, contextual product/resource links, Product notes signup, © 2026 Kivo, Privacy and Terms. Keep the full page from navigation through footer.

**Persistent sample state:**

```json
{
  "visibleRequests": 3,
  "request104": {
    "title": "Brand review",
    "status": "Awaiting review",
    "owner": "Jules Park"
  },
  "request105": {
    "title": "Access request",
    "status": "Owner assigned",
    "owner": "Cam Lee"
  },
  "request106": {
    "title": "Vendor setup",
    "status": "Submitted",
    "owner": "Unassigned"
  },
  "completedRequests": 0
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Speakeasy](https://www.speakeasy.com/) — Character-built technical illustration; use Kivo’s original routing arrow and sunflower palette.
- [Tines Pages](https://www.tines.com/stories/docs/pages/) — Forms and human input within workflows inform requester-to-reviewer handoffs.
