# Kivo — Desktop application

## Recreation prompt

Recreate a refined desktop application for **Kivo**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Internal request routing and approvals for operations teams. Core flow: submit a request, assign an owner, review and complete the handoff.

**Palette and visual character:** Muted sunflower #E8CB55, cream #F7F2E6, black #1D1D18 and brick red #CF5B3B. Confident flat blocks and rules, no glossy gradients. Original arrow assembled from tiny repeated characters and pixels, with grid-like density and a sharp 90-degree bend. Bold graphic hierarchy, rigid dividers, warm colors. Use yellow for navigation/status accents, cream for readable app work areas.

**Typography:** Space Grotesk 400/500/600/700, IBM Plex Mono 400/500 for route metadata. Use naturally proportioned lettering, clear functional text and generous spacing. [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk), weights 400, 500, 600, 700; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Full desktop software workspace for request queue and routing detail. Compact brand/workspace navigation, a clear selected destination and generous working area. REQ-104 Brand review detail. Current badge Awaiting review, owner Jules Park, a vertical three-stage route Submitted / Owner assigned / Awaiting review with first two complete and third open. Request brief: Review the launch page artwork. Include an attachment row launch-artwork.pdf (fictional fixture). Primary Review request. No completed badge. Use a wider working layout appropriate to desktop. Inbox / All requests selected. Show all three request rows at left, REQ-104 selected; Details selected in the right-hand request panel. Show owner, attachment, route and review action. Avoid decorative marketing art beyond small relevant cover images or brand touches.

**Persistent sample state:**

```json
{
  "visibleRequests": 3,
  "request104": {
    "title": "Brand review",
    "status": "Awaiting review",
    "owner": "Jules Park"
  },
  "request105": {
    "title": "Access request",
    "status": "Owner assigned",
    "owner": "Cam Lee"
  },
  "request106": {
    "title": "Vendor setup",
    "status": "Submitted",
    "owner": "Unassigned"
  },
  "completedRequests": 0
}
```

Request brief: Review the launch page artwork. Submitted May 12, 2026 at 9:14 AM; owner assigned at 10:03 AM. If showing an attachment: launch-artwork.pdf, PDF, 3.2 MB.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Speakeasy](https://www.speakeasy.com/) — Character-built technical illustration; use Kivo’s original routing arrow and sunflower palette.
- [Tines Pages](https://www.tines.com/stories/docs/pages/) — Forms and human input within workflows inform requester-to-reviewer handoffs.
