# Kivo — Product components

## Recreation prompt

Recreate a refined product components for **Kivo**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Internal request routing and approvals for operations teams. Core flow: submit a request, assign an owner, review and complete the handoff.

**Palette and visual character:** Muted sunflower #E8CB55, cream #F7F2E6, black #1D1D18 and brick red #CF5B3B. Confident flat blocks and rules, no glossy gradients. Original arrow assembled from tiny repeated characters and pixels, with grid-like density and a sharp 90-degree bend. Bold graphic hierarchy, rigid dividers, warm colors. Use yellow for navigation/status accents, cream for readable app work areas.

**Typography:** Space Grotesk 400/500/600/700, IBM Plex Mono 400/500 for route metadata. Use naturally proportioned lettering, clear functional text and generous spacing. [Space Grotesk](https://fonts.google.com/specimen/Space+Grotesk), weights 400, 500, 600, 700; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** One three-step route tracker for REQ-104 with first two stages complete and Awaiting review current. A separate owner card Jules Park and request card Brand review / Awaiting review with Review request. Use an orange/red current-step accent, yellow header and cream panels; intentional whitespace. Keep components complete and at natural proportions with generous surrounding space; show only interface content, with no external presentation labels. Omit global header, logo, search, sidebar and application navigation. The study contains exactly three component groups.

**Persistent sample state:**

```json
{
  "visibleRequests": 3,
  "request104": {
    "title": "Brand review",
    "status": "Awaiting review",
    "owner": "Jules Park"
  },
  "request105": {
    "title": "Access request",
    "status": "Owner assigned",
    "owner": "Cam Lee"
  },
  "request106": {
    "title": "Vendor setup",
    "status": "Submitted",
    "owner": "Unassigned"
  },
  "completedRequests": 0
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Speakeasy](https://www.speakeasy.com/) — Character-built technical illustration; use Kivo’s original routing arrow and sunflower palette.
- [Tines Pages](https://www.tines.com/stories/docs/pages/) — Forms and human input within workflows inform requester-to-reviewer handoffs.
