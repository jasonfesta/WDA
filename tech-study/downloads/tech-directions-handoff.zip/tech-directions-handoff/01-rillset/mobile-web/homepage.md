# Rillset — Mobile web homepage

## Recreation prompt

Recreate a refined mobile web homepage for **Rillset**, 1024 × 4608 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Dataset versioning and publishing for data engineers and analysts. Core flow: compare a candidate version, check its structure, collect review and publish a shared version.

**Palette and visual character:** Soft white #FCFBF8, charcoal #24231F, orange #E76024, very light warm gray. Flat programmatic dithering: tiny orange pixels and ASCII characters resolve from scattered source records into aligned data lanes. Thin rules, quiet grid ticks and restrained technical labels. No 3D woven ribbons, glossy objects or smooth wave sculpture.

**Typography:** Geist 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Reflow the entire homepage into a phone-width single column. Keep the full page from logo/menu to footer. Opening: headline “Good data. Out in the open.”, body “Turn working files into dependable datasets. Review the changes. Publish one version everyone can use.”, primary action “Publish a dataset”, then the characteristic artwork below the text. Middle: “A clear record of what changed.” above one simplified, readable product example. Stack working content and controls, with no desktop sidebars. Show the key task: Show Harbor routes / Fieldworks, v1.4, Ready to publish. Compare Rows 8,420 → 8,540 and Fields 12 → 13; service_region is the new field. Show the three passed checks and both approved reviewers, then Team only and Publish v1.4. Keep the task legible and focused. Closing: three benefit rows Keep the history. / Review the difference. / Share the right version., then “Make the next version the clear one.” and the primary action. Complete the footer with Datasets, Versioning, Sharing, Documentation, API, Contact, Product notes email signup, © 2026 Rillset, Privacy and Terms. Preserve generous vertical space; no cut-off panels or phone status bars.

**Persistent sample state:**

```json
{
  "dataset": "Harbor routes",
  "workspace": "Fieldworks",
  "baseline": {
    "version": "1.3",
    "rows": 8420,
    "fields": 12
  },
  "candidate": {
    "version": "1.4",
    "rows": 8540,
    "fields": 13
  },
  "addedField": "service_region",
  "checks": 3,
  "approvals": [
    "Maya Chen",
    "Theo Park"
  ],
  "visibility": "Team only",
  "status": "Ready to publish"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Firecrawl](https://www.firecrawl.dev/) — Technical labels, white space, orange emphasis and flat pixel/character fields.
- [Atta](https://atta.app/) — A clear product operation shown in an open composition.
- [lakeFS](https://lakefs.io/) — Version history, data quality and reproducibility as functional cues for dataset review.
