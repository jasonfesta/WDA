# Rillset — iOS application

## Recreation prompt

Recreate a refined ios application for **Rillset**, 875 × 1798 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Dataset versioning and publishing for data engineers and analysts. Core flow: compare a candidate version, check its structure, collect review and publish a shared version.

**Palette and visual character:** Soft white #FCFBF8, charcoal #24231F, orange #E76024, very light warm gray. Flat programmatic dithering: tiny orange pixels and ASCII characters resolve from scattered source records into aligned data lanes. Thin rules, quiet grid ticks and restrained technical labels. No 3D woven ribbons, glossy objects or smooth wave sculpture.

**Typography:** Geist 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** A complete upright phone screen from status bar at 9:41 through the bottom tab bar and home indicator. Square outer canvas, full bleed, no device frame. This screen is candidate dataset version review. Show Harbor routes / Fieldworks, v1.4, Ready to publish. Compare Rows 8,420 → 8,540 and Fields 12 → 13; service_region is the new field. Show the three passed checks and both approved reviewers, then Team only and Publish v1.4. Keep the task legible and focused. Bottom tabs in order: Datasets, Activity, Account. Only Datasets is selected. Back navigation remains under that parent destination. Keep practical touch sizes and all controls fully visible. Do not use a marketing hero layout.

**Persistent sample state:**

```json
{
  "dataset": "Harbor routes",
  "workspace": "Fieldworks",
  "baseline": {
    "version": "1.3",
    "rows": 8420,
    "fields": 12
  },
  "candidate": {
    "version": "1.4",
    "rows": 8540,
    "fields": 13
  },
  "addedField": "service_region",
  "checks": 3,
  "approvals": [
    "Maya Chen",
    "Theo Park"
  ],
  "visibility": "Team only",
  "status": "Ready to publish"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Firecrawl](https://www.firecrawl.dev/) — Technical labels, white space, orange emphasis and flat pixel/character fields.
- [Atta](https://atta.app/) — A clear product operation shown in an open composition.
- [lakeFS](https://lakefs.io/) — Version history, data quality and reproducibility as functional cues for dataset review.
