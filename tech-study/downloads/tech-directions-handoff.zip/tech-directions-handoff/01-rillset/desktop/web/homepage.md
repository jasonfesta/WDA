# Rillset — Desktop web homepage

## Recreation prompt

Recreate a refined desktop web homepage for **Rillset**, 1536 × 3072 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Dataset versioning and publishing for data engineers and analysts. Core flow: compare a candidate version, check its structure, collect review and publish a shared version.

**Palette and visual character:** Soft white #FCFBF8, charcoal #24231F, orange #E76024, very light warm gray. Flat programmatic dithering: tiny orange pixels and ASCII characters resolve from scattered source records into aligned data lanes. Thin rules, quiet grid ticks and restrained technical labels. No 3D woven ribbons, glossy objects or smooth wave sculpture.

**Typography:** Geist 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Open with a 40/60 asymmetric hero: large plain sans headline at left, flat orange dithered data field at right. Follow with a slim Harbor routes metadata bar, a large version-diff preview, three small benefit blocks, a structured JSON version example, a strong flat orange conversion panel, newsletter signup and full footer. Carry tiny pixel motifs through the page. The VERSION SHAPE example uses dataset harbor-routes, version 1.4, visibility team. Headline: “Good data. Out in the open.” Supporting copy: “Turn working files into dependable datasets. Review the changes. Publish one version everyone can use.” Primary action: “Publish a dataset”. Product section heading: “A clear record of what changed.”. Benefits: Keep the history. / Review the difference. / Share the right version. Closing headline: “Make the next version the clear one.”. Footer includes the brand, contextual product/resource links, Product notes signup, © 2026 Rillset, Privacy and Terms. Keep the full page from navigation through footer.

**Persistent sample state:**

```json
{
  "dataset": "Harbor routes",
  "workspace": "Fieldworks",
  "baseline": {
    "version": "1.3",
    "rows": 8420,
    "fields": 12
  },
  "candidate": {
    "version": "1.4",
    "rows": 8540,
    "fields": 13
  },
  "addedField": "service_region",
  "checks": 3,
  "approvals": [
    "Maya Chen",
    "Theo Park"
  ],
  "visibility": "Team only",
  "status": "Ready to publish"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Firecrawl](https://www.firecrawl.dev/) — Technical labels, white space, orange emphasis and flat pixel/character fields.
- [Atta](https://atta.app/) — A clear product operation shown in an open composition.
- [lakeFS](https://lakefs.io/) — Version history, data quality and reproducibility as functional cues for dataset review.
