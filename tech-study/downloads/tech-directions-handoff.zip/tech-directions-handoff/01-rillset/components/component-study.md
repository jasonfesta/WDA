# Rillset — Product components

## Recreation prompt

Recreate a refined product components for **Rillset**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Dataset versioning and publishing for data engineers and analysts. Core flow: compare a candidate version, check its structure, collect review and publish a shared version.

**Palette and visual character:** Soft white #FCFBF8, charcoal #24231F, orange #E76024, very light warm gray. Flat programmatic dithering: tiny orange pixels and ASCII characters resolve from scattered source records into aligned data lanes. Thin rules, quiet grid ticks and restrained technical labels. No 3D woven ribbons, glossy objects or smooth wave sculpture.

**Typography:** Geist 400/500/600 and IBM Plex Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [IBM Plex Mono](https://fonts.google.com/specimen/IBM+Plex+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Three isolated components: a wide version delta card at left; a checks card at upper right; and a publication card at lower right. Show the exact before/after values, the three checks, two approved reviewers and orange Publish v1.4 action. No global navigation or marketing art. Keep components complete and at natural proportions with generous surrounding space; show only interface content, with no external presentation labels.

**Persistent sample state:**

```json
{
  "dataset": "Harbor routes",
  "workspace": "Fieldworks",
  "baseline": {
    "version": "1.3",
    "rows": 8420,
    "fields": 12
  },
  "candidate": {
    "version": "1.4",
    "rows": 8540,
    "fields": 13
  },
  "addedField": "service_region",
  "checks": 3,
  "approvals": [
    "Maya Chen",
    "Theo Park"
  ],
  "visibility": "Team only",
  "status": "Ready to publish"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Firecrawl](https://www.firecrawl.dev/) — Technical labels, white space, orange emphasis and flat pixel/character fields.
- [Atta](https://atta.app/) — A clear product operation shown in an open composition.
- [lakeFS](https://lakefs.io/) — Version history, data quality and reproducibility as functional cues for dataset review.
