# Morrow — Product components

## Recreation prompt

Recreate a refined product components for **Morrow**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Customer-research synthesis and decision tracking. Core flow: collect interviews, connect excerpts to themes and propose decisions with traceable evidence.

**Palette and visual character:** Warm cream #F8F3E7, forest #164C3A, sage #BFCDB2, apricot #E7AB78 and terracotta #C96945. Quiet natural warmth, no neon or purple. Original cut-paper listening garden with speech shapes as leaves, fine stems connecting small source cards and an open notebook. Tactile paper edges, gentle precise shading. Keep this charming artwork in marketing, with small motif touches in working UI.

**Typography:** DM Sans 400/500/600/700, Lora 400/500 only for source quotations. Use naturally proportioned lettering, clear functional text and generous spacing. [DM Sans](https://fonts.google.com/specimen/DM+Sans), weights 400, 500, 600, 700; fallback Arial, Helvetica, sans-serif. [Lora](https://fonts.google.com/specimen/Lora), weights 400, 500; fallback Georgia, "Times New Roman", serif.

**Composition and content:** A source quote card Participant 03 with exact quote and View source; a linked Getting started theme chip 7 interviews; a decision card Clarify the first step / Amira Lee / Proposed. A light fine connector demonstrates the relation. Warm paper-colored panels, spacious precise typography. Keep components complete and at natural proportions with generous surrounding space; show only interface content, with no external presentation labels.

**Persistent sample state:**

```json
{
  "project": "Northline / First-week experience",
  "interviews": 24,
  "themes": 8,
  "visibleTheme": "Getting started",
  "themeSources": 7,
  "visibleExcerpts": 2,
  "decision": "Clarify the first step",
  "decisionOwner": "Amira Lee",
  "decisionStatus": "Proposed"
}
```

Source excerpts: Participant 03 — “I understood the goal, but not where to begin.” Participant 11 — “One clear first step would have helped.” The decision is proposed, not completed.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Clay](https://www.clay.com/) — Crafted, colorful technology storytelling; use an original paper research garden.
- [Dovetail](https://dovetail.com/) — Research projects, themes and source-linked evidence inform the research-to-decision flow.
