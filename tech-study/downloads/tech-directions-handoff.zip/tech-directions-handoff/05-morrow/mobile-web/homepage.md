# Morrow — Mobile web homepage

## Recreation prompt

Recreate a refined mobile web homepage for **Morrow**, 1024 × 4608 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Customer-research synthesis and decision tracking. Core flow: collect interviews, connect excerpts to themes and propose decisions with traceable evidence.

**Palette and visual character:** Warm cream #F8F3E7, forest #164C3A, sage #BFCDB2, apricot #E7AB78 and terracotta #C96945. Quiet natural warmth, no neon or purple. Original cut-paper listening garden with speech shapes as leaves, fine stems connecting small source cards and an open notebook. Tactile paper edges, gentle precise shading. Keep this charming artwork in marketing, with small motif touches in working UI.

**Typography:** DM Sans 400/500/600/700, Lora 400/500 only for source quotations. Use naturally proportioned lettering, clear functional text and generous spacing. [DM Sans](https://fonts.google.com/specimen/DM+Sans), weights 400, 500, 600, 700; fallback Arial, Helvetica, sans-serif. [Lora](https://fonts.google.com/specimen/Lora), weights 400, 500; fallback Georgia, "Times New Roman", serif.

**Composition and content:** Reflow the entire homepage into a phone-width single column. Keep the full page from logo/menu to footer. Opening: headline “More voices. A clearer direction.”, body “Bring interviews, notes and evidence into one shared place.”, primary action “Start a project”, then the characteristic artwork below the text. Middle: “Keep the story close to the source.” above one simplified, readable product example. Stack working content and controls, with no desktop sidebars. Show the key task: Theme detail Getting started with 7 source interviews, two comfortably spaced quote cards and View all 7 sources, then one linked decision card Clarify the first step / Amira Lee / Proposed. Parent project shown clearly. Practical content first with a small leaf motif, not a giant garden taking the app over. Closing: three benefit rows Gather the voices. / Find the connection. / Make the call together., then “Build your next decision on something real.” and the primary action. Complete the footer with Product, Collect, Understand, Decide, Resources, Contact, Product notes email signup, © 2026 Morrow, Privacy and Terms. Preserve generous vertical space; no cut-off panels or phone status bars. The mobile marketing example shows one excerpt, Participant 03, plus View all 7 sources. The iOS application shows both specified excerpts.

**Persistent sample state:**

```json
{
  "project": "Northline / First-week experience",
  "interviews": 24,
  "themes": 8,
  "visibleTheme": "Getting started",
  "themeSources": 7,
  "visibleExcerpts": 2,
  "decision": "Clarify the first step",
  "decisionOwner": "Amira Lee",
  "decisionStatus": "Proposed"
}
```

Source excerpts: Participant 03 — “I understood the goal, but not where to begin.” Participant 11 — “One clear first step would have helped.” The decision is proposed, not completed.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Clay](https://www.clay.com/) — Crafted, colorful technology storytelling; use an original paper research garden.
- [Dovetail](https://dovetail.com/) — Research projects, themes and source-linked evidence inform the research-to-decision flow.
