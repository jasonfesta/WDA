# Oriel — Desktop web homepage

## Recreation prompt

Recreate a refined desktop web homepage for **Oriel**, 1536 × 3072 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Product-update publishing for product marketers and small product teams. Core flow: draft, preview, approve, schedule and publish an edition.

**Palette and visual character:** Warm near-black #171713, ivory #F4F1E8, neutral gray #A7A69D; no colored glow. Airy surfaces with understated thin lines and rare ivory controls. Original sculptural ivory cut-paper aperture: finely spaced elliptical cuts across a curled paper sheet. Restrained and tactile. In product UI this is only the update cover artwork, not a giant background. Plenty of negative space.

**Typography:** Instrument Serif 400 for short display titles only; Inter 400/500/600 for body, navigation and controls. Use naturally proportioned lettering, clear functional text and generous spacing. [Instrument Serif](https://fonts.google.com/specimen/Instrument+Serif), weights 400; fallback Georgia, "Times New Roman", serif. [Inter](https://fonts.google.com/specimen/Inter), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif.

**Composition and content:** Open with a restrained Instrument Serif headline at left and an ivory cut-paper aperture at right. A narrow scheduled-edition strip follows. Build a generous update-preview section, three brief workflow labels, two quiet supporting benefit blocks, a spacious final invitation, signup and footer. Alternate reading areas and breathing room; never fill the page with dashboard cards. Headline: “Small updates. Lasting signal.” Supporting copy: “A considered home for the work you’ve shipped. Write, review and publish with room to think.” Primary action: “Create your first update”. Product section heading: “Give the update a little room.”. Benefits: Write with focus. / Review in context. / Publish with confidence. Closing headline: “Make the next update worth opening.”. Footer includes the brand, contextual product/resource links, Product notes signup, © 2026 Oriel, Privacy and Terms. Keep the full page from navigation through footer.

**Persistent sample state:**

```json
{
  "workspace": "Mica",
  "title": "A faster way to find your work",
  "status": "Scheduled",
  "scheduled": "2026-10-28T09:00:00Z",
  "approvedBy": "Sam Lee",
  "selectedTab": "Preview"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Resend](https://resend.com/) — Restrained neutral-black atmosphere and deliberate type scale.
- [Linear](https://linear.app/) — Fine interface detail, hierarchy and precise product organization.
- [Beamer](https://www.getbeamer.com/features) — Update feeds, approval-ready preview and scheduled publication.
