# Oriel — Product components

## Recreation prompt

Recreate a refined product components for **Oriel**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Product-update publishing for product marketers and small product teams. Core flow: draft, preview, approve, schedule and publish an edition.

**Palette and visual character:** Warm near-black #171713, ivory #F4F1E8, neutral gray #A7A69D; no colored glow. Airy surfaces with understated thin lines and rare ivory controls. Original sculptural ivory cut-paper aperture: finely spaced elliptical cuts across a curled paper sheet. Restrained and tactile. In product UI this is only the update cover artwork, not a giant background. Plenty of negative space.

**Typography:** Instrument Serif 400 for short display titles only; Inter 400/500/600 for body, navigation and controls. Use naturally proportioned lettering, clear functional text and generous spacing. [Instrument Serif](https://fonts.google.com/specimen/Instrument+Serif), weights 400; fallback Georgia, "Times New Roman", serif. [Inter](https://fonts.google.com/specimen/Inter), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif.

**Composition and content:** A calm scheduling panel with 28 Oct 2026 and 09:00 UTC, Scheduled badge and Edit schedule action. A separate edition preview card for A faster way to find your work with a small aperture image. One Approved by Sam Lee row. Arrange with exceptionally generous negative space; do not fill the canvas with cards. Keep components complete and at natural proportions with generous surrounding space; show only interface content, with no external presentation labels.

**Persistent sample state:**

```json
{
  "workspace": "Mica",
  "title": "A faster way to find your work",
  "status": "Scheduled",
  "scheduled": "2026-10-28T09:00:00Z",
  "approvedBy": "Sam Lee",
  "selectedTab": "Preview"
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Resend](https://resend.com/) — Restrained neutral-black atmosphere and deliberate type scale.
- [Linear](https://linear.app/) — Fine interface detail, hierarchy and precise product organization.
- [Beamer](https://www.getbeamer.com/features) — Update feeds, approval-ready preview and scheduled publication.
