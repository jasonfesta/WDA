# Avenor — Mobile web homepage

## Recreation prompt

Recreate a refined mobile web homepage for **Avenor**, 1024 × 4608 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Release coordination for infrastructure teams. Core flow: reserve a deployment window, pass checks, collect human approvals and start rollout only when all gates are satisfied.

**Palette and visual character:** Chalk white #F6F7F2, pale sage #DFE5D6, graphite #26332B, restrained olive. ALL surfaces LIGHT. No dark panels. Precise pale-sage release score: parallel horizontal lanes with small physical gate markers and coordination points; delicate rather than chunky. Use the reference lane/score sculpture on marketing only. Product UI is flat and practical.

**Typography:** Geist 400/500/600, Geist Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [Geist Mono](https://fonts.google.com/specimen/Geist+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Reflow the entire homepage into a phone-width single column. Keep the full page from logo/menu to footer. Opening: headline “Move together. Ship with control.”, body “Bring release windows, checks and approvals into one clear sequence.”, primary action “Book a walkthrough”, then the characteristic artwork below the text. Middle: “One window. Every team in step.” above one simplified, readable product example. Stack working content and controls, with no desktop sidebars. Show the key task: One release summary at top, a three-step track Window reserved / Checks passed / Awaiting approval, a compact Checks 6/6 section, two clear named reviewer rows, then a quiet disabled Start rollout button with Needs 1 more approval. Avoid oversize marketing type in app. Closing: three benefit rows Reserve the window. / Resolve the exceptions. / Release when ready., then “Make your next release a coordinated one.” and the primary action. Complete the footer with Platform, Checks & approvals, Integrations, Resources, Documentation, Contact, Product notes email signup, © 2026 Avenor, Privacy and Terms. Preserve generous vertical space; no cut-off panels or phone status bars.

**Persistent sample state:**

```json
{
  "release": "REL-214",
  "title": "Edge gateway 2.8.1",
  "window": "2026-11-05T14:00:00Z/2026-11-05T14:30:00Z",
  "checks": "6/6",
  "approvals": {
    "received": 1,
    "required": 2,
    "approved": "Maya Chen",
    "pending": "Rowan Bell"
  },
  "status": "Window reserved / Awaiting approval",
  "rolloutStarted": false
}
```

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Factory](https://factory.ai/) — Technical conviction and precise visual organization.
- [Opal](https://www.opal.dev/) — Large spatial composition with restrained supporting detail; retain Avenor’s light sage palette.
- [Azure Pipelines approvals and checks](https://learn.microsoft.com/en-us/azure/devops/pipelines/process/approvals?view=azure-devops) — Separate automated checks from human approvals before execution.
