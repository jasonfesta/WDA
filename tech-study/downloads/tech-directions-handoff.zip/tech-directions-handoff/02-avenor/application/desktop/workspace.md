# Avenor — Desktop application

## Recreation prompt

Recreate a refined desktop application for **Avenor**, 1536 × 1024 pixels. Use the adjacent PNG as the composition reference, preserving its proportions, full bounds and visual hierarchy. Release coordination for infrastructure teams. Core flow: reserve a deployment window, pass checks, collect human approvals and start rollout only when all gates are satisfied.

**Palette and visual character:** Chalk white #F6F7F2, pale sage #DFE5D6, graphite #26332B, restrained olive. ALL surfaces LIGHT. No dark panels. Precise pale-sage release score: parallel horizontal lanes with small physical gate markers and coordination points; delicate rather than chunky. Use the reference lane/score sculpture on marketing only. Product UI is flat and practical.

**Typography:** Geist 400/500/600, Geist Mono 400/500. Use naturally proportioned lettering, clear functional text and generous spacing. [Geist](https://fonts.google.com/specimen/Geist), weights 400, 500, 600; fallback Arial, Helvetica, sans-serif. [Geist Mono](https://fonts.google.com/specimen/Geist+Mono), weights 400, 500; fallback "Courier New", monospace.

**Composition and content:** Full desktop software workspace for release detail workspace. Compact brand/workspace navigation, a clear selected destination and generous working area. One release summary at top, a three-step track Window reserved / Checks passed / Awaiting approval, a compact Checks 6/6 section, two clear named reviewer rows, then a quiet disabled Start rollout button with Needs 1 more approval. Avoid oversize marketing type in app. Use a wider working layout appropriate to desktop. Releases / Overview selected. Six check rows, two reviewer rows, reserved window in the right inspector and a disabled Start rollout action. Avoid decorative marketing art beyond small relevant cover images or brand touches.

**Persistent sample state:**

```json
{
  "release": "REL-214",
  "title": "Edge gateway 2.8.1",
  "window": "2026-11-05T14:00:00Z/2026-11-05T14:30:00Z",
  "checks": "6/6",
  "approvals": {
    "received": 1,
    "required": 2,
    "approved": "Maya Chen",
    "pending": "Rowan Bell"
  },
  "status": "Window reserved / Awaiting approval",
  "rolloutStarted": false
}
```

Six check labels: Configuration validation; Service health; Dependency checks; Security policy; Pre-release tests; Change window compliance. Maya Chen approved at 5 Nov 2026, 12:17 UTC. Rowan Bell remains pending.

Keep the original company context and original artwork. Use no reference-company logos, slogans or customer endorsements. Do not stretch, crop or distort the interface.

## Inspiration

- [Factory](https://factory.ai/) — Technical conviction and precise visual organization.
- [Opal](https://www.opal.dev/) — Large spatial composition with restrained supporting detail; retain Avenor’s light sage palette.
- [Azure Pipelines approvals and checks](https://learn.microsoft.com/en-us/azure/devops/pipelines/process/approvals?view=azure-devops) — Separate automated checks from human approvals before execution.
