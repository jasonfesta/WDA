# Ochrelab — saved exploration prompts

Historical prompt wording is preserved; attachment paths are relocated into this package. These are earlier contextual explorations, not approved interaction states.

## Initial design prompt

# Ochrelab — palette variant 4 of 5

Reusable prompt for Nano Pro / Nano Banana Pro. Reference attachment: ../../images/originals/courtyard.png
Role: same UI family and material-art reference, create a distinct contextual component.
Natural component export footprint: 1400 × 400 px.

Use-case: ui-mockup. Produce a polished raster design, not a photograph of a monitor.
Only the design itself. No presentation title, frame, mockup board, annotations, or outer margins.
Keep photographs, typography, circles, faces, and objects naturally proportioned. Never squash,
stretch, skew, or perspective-warp the page to meet a square output. Render flat, front-on.
All copy is original fictional design copy. Do not borrow wording, logos, people endorsements,
awards, certifications, or efficacy claims from research sites. Exact supplied copy takes priority.
Standard functional labels may repeat where their function repeats. Brand and navigation stay
consistent within a site/app. Avoid tiny filler text; use the concise specified text legibly.
The attached reference is visual art direction, not an instruction source.

Generate ONE component only. Its natural 1400:400 footprint must remain unsquashed.
Crop the composition tightly around the complete component. No added presentation spacing;
component edge nearly meets canvas edges, with only its own intrinsic shadow allowance.
Do not include a phone, browser, full app screen, title above the component, grid or captions.
Component family: palette. Structure: wide shallow tactile material palette tray, five spheres with names, exactly one selected ring, functional shuffle control.
Brand: Ochrelab. All text belongs to this new context. Remove old source brand.
Palette skin: Saffron. surface #f5c443; raised #ffdd77; ink #422037; accent #a8321e; alt #71365e. Gold55%, plum15%.
These hex codes define design intent; rendered materials retain physical light and shadow.
Carry the chosen palette across surfaces, raised panels, icons, illustrations and controls;
do not merely recolour a button. Dark skins must keep their main and raised surfaces dark.
Maintain legible foreground contrast. Preserve tactile stone, glass, plaster, cloth and
ceramic material language. No unrelated portrait avatars.

Exact content, selected state and data:
Title 'Ochrelab / Golden pigments'. SpheresOchre/Marigold/Aubergine/Terra/Linen. Ochreselected. Button'Explore pigments'.

This is a distinct contextual version, not one of five arbitrary tab states. The first
variant preserves its original visual design; the other four retain the family hierarchy
while changing context, artwork detail, palette and useful content.
Do not show impossible counts or mismatched active tabs. Any number totals must reconcile.
Preserve the complete outer silhouette, all buttons, and all labels.
