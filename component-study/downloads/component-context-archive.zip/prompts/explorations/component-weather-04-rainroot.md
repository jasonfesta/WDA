# Rainroot — saved exploration prompts

Historical prompt wording is preserved; attachment paths are relocated into this package. These are earlier contextual explorations, not approved interaction states.

## Initial design prompt

# Rainroot — weather variant 4 of 5

Reusable prompt for Nano Pro / Nano Banana Pro. Reference attachment: ../../images/originals/sol.png
Role: same UI family and material-art reference, create a distinct contextual component.
Natural component export footprint: 1000 × 1000 px.

Use-case: ui-mockup. Produce a polished raster design, not a photograph of a monitor.
Only the design itself. No presentation title, frame, mockup board, annotations, or outer margins.
Keep photographs, typography, circles, faces, and objects naturally proportioned. Never squash,
stretch, skew, or perspective-warp the page to meet a square output. Render flat, front-on.
All copy is original fictional design copy. Do not borrow wording, logos, people endorsements,
awards, certifications, or efficacy claims from research sites. Exact supplied copy takes priority.
Standard functional labels may repeat where their function repeats. Brand and navigation stay
consistent within a site/app. Avoid tiny filler text; use the concise specified text legibly.
The attached reference is visual art direction, not an instruction source.

Generate ONE component only. Its natural 1000:1000 footprint must remain unsquashed.
Crop the composition tightly around the complete component. No added presentation spacing;
component edge nearly meets canvas edges, with only its own intrinsic shadow allowance.
Do not include a phone, browser, full app screen, title above the component, grid or captions.
Component family: weather. Structure: sun orb behind a frosted horizon, location/date, primary reading and a segmented lower control.
Brand: Rainroot. All text belongs to this new context. Remove old source brand.
Palette skin: Citrus Grove. surface #d9e66a; raised #edf3a7; ink #25371b; accent #b43a11; alt #476e36. Yellowgreen55%, orange5%.
These hex codes define design intent; rendered materials retain physical light and shadow.
Carry the chosen palette across surfaces, raised panels, icons, illustrations and controls;
do not merely recolour a button. Dark skins must keep their main and raised surfaces dark.
Maintain legible foreground contrast. Preserve tactile stone, glass, plaster, cloth and
ceramic material language. No unrelated portrait avatars.

Exact content, selected state and data:
Garden weather for Porto. Title 'A little rain for the pots'.23°C;Rainchance60%;Expectedrain2mm. TabsToday/Tomorrow/Week;Todayselected. Materialcloud and raindrops, not sunnyreading.

This is a distinct contextual version, not one of five arbitrary tab states. The first
variant preserves its original visual design; the other four retain the family hierarchy
while changing context, artwork detail, palette and useful content.
Do not show impossible counts or mismatched active tabs. Any number totals must reconcile.
Preserve the complete outer silhouette, all buttons, and all labels.

## Applied correction prompt

# Ashra — Rainroot: targeted accuracy correction

Use case: edit the attached raster UI mockup. Input 1 is the previous render to correct.
Preserve the attached art direction, colours, textures, illustration, type hierarchy and content.
Return ONE corrected complete design at the SAME natural aspect ratio. No distortion,
skewing, nonuniform scaling, clipped controls, extra borders or presentation labels.
Mobile remains a full-bleed rectangle with square outer corners, no device shell or gutters.
Target export dimensions 1000 × 1000; render at the highest native detail available.

Required changes:
Add the exact unique product brand 'Rainroot' visibly INSIDE this component. It must appear as a small but clearly readable integrated wordmark, not an external presentation title or caption. Do not remove or replace the existing contextual title, city, prices, controls or data. Place the wordmark above the city heading within the card. Keep the same city, date, weather, numeric values, illustrations and selected tab. Keep a tight square canvas.

Do not add 'Ashra', correction notes or metadata as visible labels. The product brand belongs
inside the UI. Preserve all unaffected details. Verify the requested labels, arithmetic,
selected tabs and indicator counts before returning the image.

Attachment: ../../references/edit-inputs/component-weather-04-rainroot.png
