# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use warm porcelain #F7F4EC, dark ink #242C2B, cinnabar #C64B36 and muted sage #B9C5B6. Use a refined sturdy serif for the Agenda identity, prominent headings and selected editorial text, with clean native sans-serif metadata and controls. The recurring illustration is a cream accordion week threaded by a cinnabar pencil, supported by a sage bookmark and small stationery details. Keep crisp paper planes, restrained shading and deliberate negative space.

Show Agenda in a compact top toolbar with search and add icons. Use a serif Today title and Tuesday, October 27. Place a modest accordion-week and pencil illustration beside the heading. The date strip is Mon 26, Tue 27, Wed 28, Thu 29, Fri 30, Sat 31, Sun 1, with Tuesday selected in cinnabar.
Under Today / 4 tasks, show Review project brief / Work · 09:00 selected with a pale warm tint; Book dentist / Personal · 12:30; Collect parcel / Home · 17:00; Read for twenty minutes / Personal · Evening. Use unchecked circles, fine separators and small contextual icons.
The Notes section shows Make room for the afternoon. and “Finish the brief first. Keep the rest of the day flexible.” with a tiny paper-and-pencil spot. Tomorrow contains Send revised proposal / Work · 10:00. Bottom tabs are Today, Upcoming, Notes and Browse.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
