# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use warm porcelain #F7F4EC, dark ink #242C2B, cinnabar #C64B36 and muted sage #B9C5B6. Use a refined sturdy serif for the Agenda identity, prominent headings and selected editorial text, with clean native sans-serif metadata and controls. The recurring illustration is a cream accordion week threaded by a cinnabar pencil, supported by a sage bookmark and small stationery details. Keep crisp paper planes, restrained shading and deliberate negative space.

Use a warm light sidebar with Agenda, Search, Inbox 7, Today 4 selected, Upcoming, Someday and Notes 12. Projects contains Work, Personal and Home with small colored dots. Jamie S. and Settings sit at the bottom.
The central panel is Today, Tuesday, October 27, with a List / Calendar switch, List selected, and Add a task. A small folded-paper week illustrates Mon 26 through Sun 1, with Tuesday 27 highlighted. Four unchecked task rows read Review project brief / 09:00 / Work selected, Book dentist / 12:30 / Personal, Collect parcel / 17:00 / Home, and Read for twenty minutes / This evening / Personal. Tomorrow, Wednesday, October 28 contains Send revised proposal / 10:00 / Work. A Notes row contains Make room for the afternoon. and “Finish the brief first. Keep the rest of the day flexible.”, followed by Add a note.
The integrated inspector shows Review project brief, Work, Today, Oct 27 · 09:00, Reminder · 10 minutes before and Priority · High. Read the latest draft is checked; Add three comments and Send feedback are unchecked. Include “Focus on the opening and the next steps.”, Project brief.pdf, Complete task and Save changes.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
