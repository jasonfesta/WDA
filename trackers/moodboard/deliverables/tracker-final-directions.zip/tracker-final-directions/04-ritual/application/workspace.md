# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use vivid ultramarine, white and black. Set compact but forceful titles in a very heavy condensed sans serif, with small monospaced indices and readable interface body text. Use precise rules, square completion marks and deliberate open space. Photography is high-contrast documentary black and white. The habit record should be immediately understandable and free of decorative gauges or boxed dashboard modules.

Use a light sidebar with RITUAL, Search habits, notes…, This week selected, Today, Habits, Field notes and Archive. A Habits group contains All habits, Health, Mind and Productivity; profile and Settings are at the bottom.
The central heading is WEEK 44 with OCT 26 – NOV 1, Today navigation and New habit. Habits is the selected tab beside Notes. Use a clear three-row weekly matrix with columns Mon 26, Tue 27, Wed 28, Thu 29, Fri 30, Sat 31 and Sun 1. Tuesday is current. WALK / 20 min outside is complete on Monday and Tuesday. READ / 20 pages is complete on Monday; its Tuesday cell is selected and empty. RESET / Clear the desk · 5 min is complete on Monday and incomplete Tuesday. All future cells are empty. Show Today: 1 of 3 complete and 33%.
Field notes contains “Walked before opening my inbox. Keep that.” / 08:40 / Today and “A quieter start.” / 07:55 / Yesterday. The right inspector is 02 / READ, 20 pages · Daily, with an open-book monochrome photograph and the matching seven-day record. Add the note “Leave the book on the desk before bed.”, Reminder 21:00, Repeat Every day, Choose the next chapter checked, Read twenty pages unchecked, Mark today done and Edit habit.

## Research inspiration

- [Ascension / Landing Love](https://www.landing.love/sites/ascension/) — Visual reference for strong differences in type scale, small index annotations and asymmetric editorial placement.
- [Landing Love](https://www.landing.love/) — Broader editorial composition research. The ultramarine habit matrix, checklist language and documentary imagery are original to RITUAL.
