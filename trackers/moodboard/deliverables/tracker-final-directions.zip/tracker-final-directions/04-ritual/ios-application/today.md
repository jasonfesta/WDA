# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use vivid ultramarine, white and black. Set compact but forceful titles in a very heavy condensed sans serif, with small monospaced indices and readable interface body text. Use precise rules, square completion marks and deliberate open space. Photography is high-contrast documentary black and white. The habit record should be immediately understandable and free of decorative gauges or boxed dashboard modules.

Show a small RITUAL wordmark and black add control in the toolbar. Use TODAY. as the strong blue title, TUE 27 OCT, and WEEK 44. The week strip runs Mon 26 to Sun 1 with Tuesday 27 selected.
Show three open ruled habit rows: 01 WALK / 20 min outside, complete with a solid blue square and check; 02 READ / 20 pages, incomplete; 03 RESET / Clear the desk · 5 min, incomplete. The summary reads 1 OF 3 COMPLETE with a thin progress line at approximately one third.
Under FIELD NOTES, show 08:40 and “Walked before opening my inbox. Keep that.” Include Add a note and a modest monochrome walking photograph as the note attachment. Under RETURN TOMORROW, show the three habit names again as a quiet upcoming list. Bottom tabs are Today, Record, Notes and Profile, with Today selected.

## Research inspiration

- [Ascension / Landing Love](https://www.landing.love/sites/ascension/) — Visual reference for strong differences in type scale, small index annotations and asymmetric editorial placement.
- [Landing Love](https://www.landing.love/) — Broader editorial composition research. The ultramarine habit matrix, checklist language and documentary imagery are original to RITUAL.
