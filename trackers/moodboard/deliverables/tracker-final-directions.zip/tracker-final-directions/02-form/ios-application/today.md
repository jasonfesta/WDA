# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use white and graphite, richly detailed cobalt-blue track photography and small acid-yellow functional accents. Use tall condensed display type for screen titles and training names, with normal-width neutral sans serif for navigation, task rows, metadata and notes. Photography should show believable human movement in an architectural athletic setting. Keep progress tied to sessions rather than decorative gauges.

Show FORM’s training planner for Sunday, October 25. The top toolbar contains the spaced FORM wordmark and avatar. Under TODAY, show the week Monday 19 through Sunday 25. Only Monday, Wednesday and Saturday are complete; Sunday is selected and still planned. The summary reads “140 min completed · 3 sessions”.
A shallow cobalt-track athlete photograph introduces the next session, 20 min Mobility, and an acid-yellow Start session action. Under Your plan, show three unchecked rows: Warm up / 5 min · Ankles and hips; Mobility flow / 12 min · Full body; Cool down / 3 min · Easy breathing. The durations total 20 minutes. Under Training notes, show “After Saturday’s run” and “Legs feel heavy. Keep today’s session easy.” Include an edit icon. Bottom tabs are Today, Plan, Notes and Profile.

## Research inspiration

- [Phive / Landing Love](https://www.landing.love/sites/phive/) — Visual reference for athletic photography, confident type-to-image scale and unequal editorial image proportions.
- [Peloton App](https://www.onepeloton.com/app) — Functional research into weekly activity, visible session imagery, a next-session action and persistent app navigation.
- [Peloton Strength+](https://www.onepeloton.com/strength-plus-app?locale=en-us) — Functional reference for exercise instructions, duration and a clear next step close to the workout.
