# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use white and graphite, richly detailed cobalt-blue track photography and small acid-yellow functional accents. Use tall condensed display type for screen titles and training names, with normal-width neutral sans serif for navigation, task rows, metadata and notes. Photography should show believable human movement in an architectural athletic setting. Keep progress tied to sessions rather than decorative gauges.

Use a charcoal sidebar with FORM, Search, Today selected with count 1, Training plan, Sessions, Progress and Notes. A Library group contains Saved sessions and Programs; profile and Settings anchor the bottom.
The white central panel is TODAY, Sunday, October 25. A connected week strip runs Mon 19 through Sun 25, with completion marks on Mon 19, Wed 21 and Sat 24; Sunday is selected but incomplete. Show “140 min completed · 3 sessions”. Use a shallow photograph of an athlete stretching beside a cobalt track.
Your plan contains 20 min Mobility / Recovery · Full body / Today selected; 30 min Easy run / Mon, Oct 26; 25 min Strength / Tue, Oct 27; Recovery walk / Wed, Oct 28. Recent sessions contains 40 min Endurance run / Sat, Oct 24, 50 min Strength / Wed, Oct 21, and 50 min Easy run / Mon, Oct 19. These three completed sessions total 140 minutes. Include Add session.
The right inspector has a contextual athlete photograph, 20 MIN MOBILITY, Recovery · Full body, three unchecked steps Warm up 5 min, Mobility flow 12 min and Cool down 3 min. Include the note “Legs feel heavy. Keep today’s session easy.”, Planned / Sun, Oct 25, Equipment / Mat, acid-yellow Start session and secondary Edit plan.

## Research inspiration

- [Phive / Landing Love](https://www.landing.love/sites/phive/) — Visual reference for athletic photography, confident type-to-image scale and unequal editorial image proportions.
- [Peloton App](https://www.onepeloton.com/app) — Functional research into weekly activity, visible session imagery, a next-session action and persistent app navigation.
- [Peloton Strength+](https://www.onepeloton.com/strength-plus-app?locale=en-us) — Functional reference for exercise instructions, duration and a clear next step close to the workout.
