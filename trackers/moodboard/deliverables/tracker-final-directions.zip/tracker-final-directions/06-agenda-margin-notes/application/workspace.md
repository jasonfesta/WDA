# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use porcelain #FFFDF8, near-black plum #302831, smoke lilac #D9D4E0 and a restrained vermilion #B54536 accent. Use elegant serif headings and clean readable sans-serif interface text. Original fine ink illustrations recur around a notebook, fountain pen, cup and a red leaf. Keep controlled organic contours, restrained paper character and generous margins. Use lilac for selection without reducing text contrast.

Use a light sidebar with Agenda, Search, Inbox 3, Today 4 selected, Upcoming and All notes 12. My Notebooks contains Work 4, Personal 3, Ideas 3 and Home 2; these notebook counts sum to 12. Profile and Settings sit at the bottom.
The central Today panel is dated Tuesday, October 27 and has Tasks / Notes controls and Add. Show Review project brief / 09:00 · Work, Book dentist / 12:30 · Personal, Collect parcel / 17:00 · Home and Read for twenty minutes / This evening. All four remain incomplete. Include Add a task.
Under Notes, select A quieter day works, too. / 08:45 with a lilac row and the preview Leave space between appointments. Follow it with Ideas for next week / Yesterday and Project references / 6 links / Oct 25.
The right note editor shows Today · 08:45, bookmark, Done and overflow controls; the serif title A quieter day works, too.; and “Leave space between appointments. The brief is the only thing that needs a long stretch.” Include a small fountain pen and red leaf drawing. Linked tasks contains Review project brief / 09:00, unchecked. Keep the afternoon open is unchecked; Move loose ideas to Someday is checked. Add formatting, checklist and attachment controls and a plum Save note button.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
