# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use porcelain #FFFDF8, near-black plum #302831, smoke lilac #D9D4E0 and a restrained vermilion #B54536 accent. Use elegant serif headings and clean readable sans-serif interface text. Original fine ink illustrations recur around a notebook, fountain pen, cup and a red leaf. Keep controlled organic contours, restrained paper character and generous margins. Use lilac for selection without reducing text contrast.

Use a small serif Agenda wordmark with search and add icons. The title is Today, with Tuesday, October 27 and a vermilion date accent. A lilac Tasks / Notes segmented control has Tasks active.
Show four unchecked rows: Review project brief / 09:00 · Work; Book dentist / 12:30 · Personal; Collect parcel / 17:00 · Home; Read for twenty minutes / This evening. Place Add a task below them.
Under A NOTE FOR TODAY, use the serif title “A quieter day works, too.” and the text “Leave space between appointments. The brief is the only thing that needs a long stretch.” Place a small ink notebook, pen and single red leaf at the margin. A quiet All notes row shows 12. Bottom tabs are Today, Upcoming, Notes and Browse, with Today selected in plum.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
