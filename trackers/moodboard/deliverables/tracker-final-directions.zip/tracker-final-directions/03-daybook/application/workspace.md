# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use deep cobalt #203C91, pale butter #F5EBAE, porcelain white and tiny persimmon accents. Use a warm distinctive grotesk for headings, readable sans-serif interface text and small restrained numerical labels. A recurring original cobalt ink illustration of books, leaves and a simple figure provides personality. Give illustration subtle printmaking character while keeping the interface clean. Favor continuous lists and fine rules.

Use a pale-butter sidebar with the lowercase daybook wordmark, Search, Today selected, This week, Someday and All notes. Projects contains Work and Personal; profile and Settings sit at the bottom.
The central panel shows Today, Monday, October 26, 2h 15m planned and the week Mon 26 through Sun 1 with Monday selected. Under Make room for, select Draft project brief / Work · 09:00 · 60 min. Expand its checklist: Outline three directions checked, Add reference images unchecked, Write recommendation unchecked. Show Review research / Work · 11:00 · 45 min and Plan next week / Personal · 16:30 · 30 min. Include Add task.
The lower Notes section lists One thing at a time., Ideas for later, and Research board / 6 references. The right inspector is Draft project brief with Work, Today, October 26, 09:00 and 60 min. Repeat the checklist with identical completion states. Add Keep it focused. and “Lead with the idea. Use one clear example for each direction.”, a small cobalt book-and-leaf drawing, Research board / 6 references attachment, and Complete task / Save note buttons.

## Research inspiration

- [Notion](https://www.notion.com/) — Early visual research into clear document-like product canvases, bold straightforward typography, open space and useful task hierarchy. The cobalt-and-butter identity and illustration system are original.
- [Supaste / Navbar Gallery](https://www.navbar.gallery/navbar/supaste) — Website reference for compact navigation scale and a clear relationship between identity, links and primary action.
- [Supaste website](https://www.supaste.com/) — Supporting navigation study; the illustration, palette and task content belong to Daybook.
