# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use deep cobalt #203C91, pale butter #F5EBAE, porcelain white and tiny persimmon accents. Use a warm distinctive grotesk for headings, readable sans-serif interface text and small restrained numerical labels. A recurring original cobalt ink illustration of books, leaves and a simple figure provides personality. Give illustration subtle printmaking character while keeping the interface clean. Favor continuous lists and fine rules.

Use a butter header and white content area. The top toolbar has a small open-book symbol, lowercase daybook wordmark, search and add controls. The title is Today, dated Monday, October 26, with 2h 15m planned. Show the exact date strip Mon 26, Tue 27, Wed 28, Thu 29, Fri 30, Sat 31, Sun 1; Monday is selected.
Under Make room for, show Draft project brief / Work · 60 min · 09:00, Review research / Work · 45 min · 11:00, and Plan next week / Personal · 30 min · 16:30. All are unchecked. The first task has a slim blue active line and an unchecked indented subtask, Outline three directions.
Under Notes, show One thing at a time. with “Keep the morning clear for the brief. Save new ideas for later.” and a small cobalt book-and-leaf drawing. Add Ideas for later with “A few thoughts on the workshop, and places to explore.” and Updated yesterday. Bottom tabs are Today, Week, Notes and Someday; Today is selected. A blue add control sits above the lower navigation.

## Research inspiration

- [Notion](https://www.notion.com/) — Early visual research into clear document-like product canvases, bold straightforward typography, open space and useful task hierarchy. The cobalt-and-butter identity and illustration system are original.
- [Supaste / Navbar Gallery](https://www.navbar.gallery/navbar/supaste) — Website reference for compact navigation scale and a clear relationship between identity, links and primary action.
- [Supaste website](https://www.supaste.com/) — Supporting navigation study; the illustration, palette and task content belong to Daybook.
