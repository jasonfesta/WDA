# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use a cool porcelain canvas, near-black text, muted gray-green accents and hairline gray dividers. Set the wordmark, principal headings and large amounts in a refined regular-weight serif. Use a precise neutral sans serif for controls, metadata and body text. Keep the financial hierarchy calm, compact and legible. Avoid bright decorative colors and repeated boxed cards.

Show Ledger’s Today screen dated Tuesday, October 27. Place a small Ledger wordmark and profile control in the top toolbar. Under the large serif Today title, use one shallow textured gray-green money strip with $960, “Available this month” and “After spending and upcoming bills”. A Tasks / Notes segmented control has Tasks selected.
Under “To review”, show three open tasks: Review Northline Energy / $142.80 · Utilities · Oct 24; Confirm insurance renewal / $320 · Due Nov 7; File October statement / Documents · This month. Expand the first row with the note “Check the revised tariff before filing.” and October statement.pdf. Under Upcoming, show Utilities / Nov 1 / $180 and Internet / Nov 3 / $80. Include the saved note October review with “Keep next month’s buffer unchanged.” Bottom tabs are Today, Activity, Notes and Accounts, with Today selected. Keep the money strip shallow enough for tasks and notes to remain the main content.

## Research inspiration

- [Harvey website](https://www.harvey.ai/) — Visual reference for restrained serif and sans-serif hierarchy, off-white surfaces, black actions and the contrast between dark navigation and a pale workspace.
- [Harvey Command Center](https://www.harvey.ai/platform/command-center) — Product reference for an overview that leads into reviewable information and contextual actions.
- [Harvey Contract Intelligence](https://www.harvey.ai/platform/contract-intelligence) — Workflow reference for a selected row connected to an integrated detail inspector.
- [Harvey Vault](https://www.harvey.ai/platform/vault) — Reference for document context, source attachments, search, filters and sober table structure.
