# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use a cool porcelain canvas, near-black text, muted gray-green accents and hairline gray dividers. Set the wordmark, principal headings and large amounts in a refined regular-weight serif. Use a precise neutral sans serif for controls, metadata and body text. Keep the financial hierarchy calm, compact and legible. Avoid bright decorative colors and repeated boxed cards.

Use a narrow top toolbar with Ledger at left, a search field, Personal workspace selector, notifications, help and profile. The dark left sidebar contains Ledger, Search, Today selected, Transactions, Bills, Accounts and Notes; an Accounts group lists Everyday account and Savings; Jamie S. and Settings sit at the bottom.
The central panel is Today, Tuesday, October 27, with Add task. Three unboxed summary values read $960 Available this week, $260 Upcoming and 3 To review. The filters read All (6), To review (3), Upcoming (2), Notes (1). Show Northline Energy / Utilities · Oct 24 / $142.80 selected with Needs review, Confirm insurance renewal / Nov 7 / $320, and File October statement. Upcoming contains Utilities / Nov 1 / $180 and Internet / Nov 3 / $80. Notes contains October review / 2 linked tasks.
The integrated right inspector shows Northline Energy, $142.80, Utilities · Oct 24, 2026 and Needs review. Editable fields are Account / Everyday, Category / Utilities and Source / October statement.pdf. Compare with September is checked; Confirm new rate is unchecked. The note reads “Check the revised tariff before filing.” Include the statement attachment and Mark reviewed / Edit note actions. Keep the selected transaction and inspector amount identical.

## Research inspiration

- [Harvey website](https://www.harvey.ai/) — Visual reference for restrained serif and sans-serif hierarchy, off-white surfaces, black actions and the contrast between dark navigation and a pale workspace.
- [Harvey Command Center](https://www.harvey.ai/platform/command-center) — Product reference for an overview that leads into reviewable information and contextual actions.
- [Harvey Contract Intelligence](https://www.harvey.ai/platform/contract-intelligence) — Workflow reference for a selected row connected to an integrated detail inspector.
- [Harvey Vault](https://www.harvey.ai/platform/vault) — Reference for document context, source attachments, search, filters and sober table structure.
