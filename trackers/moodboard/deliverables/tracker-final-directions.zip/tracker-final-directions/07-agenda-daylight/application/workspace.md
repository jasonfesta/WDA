# Recreation prompt

Recreate a 1586 × 992 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete landscape desktop application image, filling the canvas edge to edge. Use the companion [iOS screen](../ios-application/today.png) and [desktop homepage](../web/homepage.png) for consistent identity and content.

Show a persistent navigation sidebar, a slim toolbar, a populated central workspace and an integrated right detail inspector or note editor. The sidebar includes navigation, project or category groups, profile and settings. The main area includes a date or page heading, useful filters or view controls, task or record rows, a selected item and an add affordance. The right panel reveals the selected item’s actual metadata, notes, checklist, attachments and actions. Separate these areas with space and quiet rules rather than a collection of disconnected cards.

Use clear readable interface text, consistent icons, precise alignment and sensible desktop information density. Keep related amounts, dates, selections and completion states consistent across the list and inspector. Use photographs or illustrations as contextual details. Show one coherent application, with no marketing sections or surrounding device presentation.

Use warm cream #F8F5E9, deep forest #24483D, terracotta #C77858 and muted apricot #EAC8A2. Use warm readable sans-serif headings and precise interface text. Original illustrated courtyard scenes recur around a green-shuttered window, terracotta roofs, a cup, calendar and key. Keep crisp simplified forms, carefully layered color planes and atmospheric light. Use illustration in modest contextual areas so the tasks remain primary.

Use a warm cream application with Agenda, a global search field and a narrow courtyard-window illustration integrated into the top toolbar. The sidebar contains Inbox 7, Today 4 selected, Upcoming and Notes 12; Projects contains Work, Personal and Home; include New project, Jamie S. and Settings.
The center panel shows Today, Tuesday, October 27, List / Calendar with List selected, and the date strip Mon 26 through Sun 1 with Tuesday 27 selected. Show four incomplete tasks: Review project brief / Work / 09:00, Book dentist / Personal / 12:30, Collect parcel / Home / 17:00 selected with a pale forest tint, and Read for twenty minutes / Personal / Any time. Collect parcel must retain an EMPTY completion circle; selection does not mean completion.
Tomorrow, Wednesday, October 28 contains Send revised proposal / Work / 10:00. The Notes row is Leave the afternoon open, “Take the longer way home after the parcel pickup.” and Updated 08:45. Include an add control.
The right inspector is Collect parcel, Home, Today · 17:00 and Reminder · 16:45. The note reads “Take the longer way home. The pickup counter closes at 18:00.” Bring collection code is checked; Bring a tote bag is unchecked. Show Pickup details / PDF · 248 KB, terracotta Complete task and secondary Add note.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
