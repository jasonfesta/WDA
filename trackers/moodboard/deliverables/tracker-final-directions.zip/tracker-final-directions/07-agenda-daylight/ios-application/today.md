# Recreation prompt

Recreate an 853 × 1844 pixel image, or a proportionally larger image with the same aspect ratio. Preserve the complete composition and all visible content.

Create one complete portrait iOS application image. Show the signed-in product with tasks and notes, using the full canvas without surrounding phone hardware or presentation labels. Use the companion [desktop homepage](../web/homepage.png) to maintain this direction’s palette, typography and illustration or photographic language.

Include a 9:41 status bar, appropriate safe areas, a compact toolbar, consistent native-style icons, readable body text, generous touch targets, fine separators, a persistent four-tab navigation bar with labels and a home indicator. Keep data, dates, completion states and selected controls internally consistent. The screen should feel like an inner application, with continuous content rather than a wall of cards. Keep illustrations subordinate to the tasks and notes. Show all content within the screen.

Use warm cream #F8F5E9, deep forest #24483D, terracotta #C77858 and muted apricot #EAC8A2. Use warm readable sans-serif headings and precise interface text. Original illustrated courtyard scenes recur around a green-shuttered window, terracotta roofs, a cup, calendar and key. Keep crisp simplified forms, carefully layered color planes and atmospheric light. Use illustration in modest contextual areas so the tasks remain primary.

Use Agenda in a compact toolbar with a profile circle. Under it, place a shallow courtyard-window illustration strip occupying roughly 12–14% of screen height. Include the green shutters, cup, calendar and key. Below it, use a Today / This week segmented control with Today selected, then Today, Tuesday, October 27 and “A little room in your day.”
Show four unchecked rows with fine dividers: Review project brief / 09:00 · Work; Book dentist / 12:30 · Personal; Collect parcel / 17:00 · Home; Read for twenty minutes / Evening · Personal.
Under Notes, show See all and a note titled Leave the afternoon open with “Take the longer way home after the parcel pickup.”, Updated 08:45 and a small key illustration. A terracotta add control sits above the bottom navigation. Tabs are Today, Upcoming, Notes and Browse, with Today selected in forest green.

## Research inspiration

- [Todoist features](https://www.todoist.com/features) — Functional reference for Today and Upcoming, a familiar sidebar, open task rows, completion controls and concise due-date metadata. The illustration language is original.
- [Things features](https://culturedcode.com/things/features/) — Functional reference for careful task hierarchy, readable scheduling and details revealed in context.
- [Brigit Hickey / Mailchimp relaunch](https://www.brigithickey.com/work/mailchimp-relaunch) — Illustration research into purposeful commissioned images that support specific product stories.
- [BUCK / Shopify](https://buck.co/work/shopify) — Illustration research into a coherent visual system that works across large compositions and small supporting details.
