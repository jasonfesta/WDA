# Recreation prompt

Create a complete 749 × 2100 px responsive mobile website homepage. Use the paired website page in ../web/homepage.png as the composition and content reference, reflowed for a single narrow scrolling viewport. Keep the same brand, copy, products, photography style, prices and section order. This is the mobile website, with a compact browser address bar, a responsive site header and menu button.

Brand: Bowlfolk. Rich aubergine chunky friendly typography, cream negative space, buttery-yellow summary blocks, blush food pouches and real terrier photography; warm premium pet-food editorial design.

Typography: [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 500, 600, 700, 800; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #38213F, #FBF7EF, #FAE9B3, #EFC6B9. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation links: Our food · How it works · Meet Bowlfolk. Primary action: Build my dog’s plan.

Hero: huge aubergine friendly headline on warm cream, candid terrier with blush Bowlfolk food pouch on right, buttery yellow accent, 'Build my dog’s plan' button. Recipe row: Beef & garden veg, Turkey & pumpkin, Chicken & brown rice, original pastel packaging and actual bowls of fresh food. Starter-plan preview: Milo, terrier mix,3 years,24 lb; Beef and Turkey selected; 14 days 56 and 4 perday; Then 112 every 28 days; deliveryincluded; 'Build my dog’s plan'. Story: photograph of hands preparing ingredients left, 'Real food, familiar ingredients' right, no medical claims. Process: Tell us about your dog / Choose two recipes / Set your first delivery. FAQ 'How does the plan renew?' — 'After the first 14 days, $112 every 28 days for this example plan.'; 'Can I pause?' — 'Pause or cancel before your next renewal.' Community photo strip of four dogs and their mealtimes, no testimonials. Newsletter 'A little more tail-wagging', email and Subscribe. Footer Bowlfolk, Our food, Plans, Delivery, Help, Privacy, Instagram.

Reflow wide layouts into one column; use two-column product grids only where labels remain comfortably readable. Keep purchase choices, prices, quantity and the primary action visible together. Stack forms and footer links naturally. Preserve full page height, complete newsletter and footer, original object proportions and readable typography. No native app tab bar, floating device frame, squeezed desktop page, clipping or outer presentation margins.

# Inspiration

- [The Farmer’s Dog — Our Food](https://www.thefarmersdog.com/our-food) — Personalized fresh-food plans and recipe presentation.
- [The Farmer’s Dog — Onboarding](https://www.thefarmersdog.com/signup/me/GetStarted) — The public introduction to dog-profile, plan and checkout sequencing; later screens are an original synthesis.
- [Agrumea Farm](https://agrumeafarm.it/en) — Memorable original packaging, warm ingredient photography and restrained color.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — An expressive, confident food-brand voice.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — Clear selected controls and readable action hierarchy.
