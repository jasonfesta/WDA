# Recreation prompt

Create a 1747 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Bowlfolk. Rich aubergine chunky friendly typography, cream negative space, buttery-yellow summary blocks, blush food pouches and real terrier photography; warm premium pet-food editorial design.

Typography: [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 500, 600, 700, 800; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #38213F, #FBF7EF, #FAE9B3, #EFC6B9. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: Milo, terrier mix, 3 years, 24 lb; two selected recipes Beef & garden veg and Turkey & pumpkin. Chicken & brown rice unselected. First 14 days $56 = $4/day. Then $112 every 28 days, delivery included. First delivery 7 Nov 2026. No medical nutrition claims. Fictional address 123MarketSt; Visa 4242.

Screen 1: Meet your best friend
Entry: Start a food plan.
Selected state: Your dog / step1.
Visible content: Bowlfolk, warm terrier portrait, simple fields Name Milo; Breed Terrier mix; Age 3 years; Weight 24 lb; no hidden medical questions. Progress Your dog active, Recipes, Review, Confirmed. CTA 'Find Milo’s meals'.
Primary action: Find Milo’s meals.
Result: Dog profile saved.

Screen 2: Milo’s menu
Entry: Save dog profile.
Selected state: Beef + Turkey / 2 recipes.
Visible content: Two selected recipe rows Beef & garden veg and Turkey & pumpkin with pouches and clear checkmarks; third Chicken & brown rice unselected. Summary '2 recipes selected', '14 days · $56', '$4 per day'. Small 'Then $112 every 28 days'. CTA 'Review first box'.
Primary action: Review first box.
Result: 2 recipes selected.

Screen 3: Milo’s first box
Entry: Review first box.
Selected state: Review / Visa4242.
Visible content: Beef + Turkey, 14 days, $56 total; delivery included; first delivery 7Nov; address 123MarketSt Edit; Visa••••4242. Explicit 'Then $112 every 28 days. Pause or cancel before renewal.' CTA 'Start plan · $56'.
Primary action: Start plan · $56.
Result: Recurring terms reviewed.

Screen 4: Good days start here
Entry: Start plan successfully.
Selected state: Confirmed.
Visible content: Happy terrier and Bowlfolk pouch. 'Milo’s plan is ready'; first box 7Nov, 14 days, Beef + Turkey, Paid$56. Small next renewal 21Nov $112 for 28 days. CTA 'Manage Milo’s plan'; secondary View feeding guide. No health claims.
Primary action: Manage Milo’s plan.
Result: Plan active; next renewal21Nov112.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday.

# Inspiration

- [The Farmer’s Dog — Our Food](https://www.thefarmersdog.com/our-food) — Personalized fresh-food plans and recipe presentation.
- [The Farmer’s Dog — Onboarding](https://www.thefarmersdog.com/signup/me/GetStarted) — The public introduction to dog-profile, plan and checkout sequencing; later screens are an original synthesis.
- [Agrumea Farm](https://agrumeafarm.it/en) — Memorable original packaging, warm ingredient photography and restrained color.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — An expressive, confident food-brand voice.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — Clear selected controls and readable action hierarchy.
