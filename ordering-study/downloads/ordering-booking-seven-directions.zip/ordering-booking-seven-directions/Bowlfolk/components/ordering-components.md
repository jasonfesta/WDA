# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Bowlfolk. Rich aubergine chunky friendly typography, cream negative space, buttery-yellow summary blocks, blush food pouches and real terrier photography; warm premium pet-food editorial design.

Typography: [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 500, 600, 700, 800; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #38213F, #FBF7EF, #FAE9B3, #EFC6B9. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Pet-profile compact form with Milo/terriermix/3 years/24 lb and a separate invalid weight field 'Enter a weight above 0 lb'; recipe row selected Beef, selected Turkey, unselected Chicken and 2 selected count; buttery plan summary 14 days 56 $4/day then 112/28 days; address/date and masked paymentrows; clear subscription terms next to Start plan 56; confirmation card firstdelivery 7Nov next 21Nov 112. Buttons disabled Continue, enabled Review first box, loading Starting plan; distinct unobstructed close and back targets.

Persistent data: Milo, terrier mix, 3 years, 24 lb; two selected recipes Beef & garden veg and Turkey & pumpkin. Chicken & brown rice unselected. First 14 days $56 = $4/day. Then $112 every 28 days, delivery included. First delivery 7 Nov 2026. No medical nutrition claims. Fictional address 123MarketSt; Visa 4242.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday.

# Inspiration

- [The Farmer’s Dog — Our Food](https://www.thefarmersdog.com/our-food) — Personalized fresh-food plans and recipe presentation.
- [The Farmer’s Dog — Onboarding](https://www.thefarmersdog.com/signup/me/GetStarted) — The public introduction to dog-profile, plan and checkout sequencing; later screens are an original synthesis.
- [Agrumea Farm](https://agrumeafarm.it/en) — Memorable original packaging, warm ingredient photography and restrained color.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — An expressive, confident food-brand voice.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — Clear selected controls and readable action hierarchy.
