# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Bowlfolk. Rich aubergine chunky friendly typography, cream negative space, buttery-yellow summary blocks, blush food pouches and real terrier photography; warm premium pet-food editorial design.

Typography: [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 500, 600, 700, 800; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #38213F, #FBF7EF, #FAE9B3, #EFC6B9. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Cream desktop recipe-selection screen with Bowlfolk wordmark, a four-stage Your dog / Recipes / Review / Confirmed progress bar with Recipes active, and Milo’s profile. Large headline: Fresh bowls. Happy dogs. Three horizontal recipe rows on the left; Beef & garden veg and Turkey & pumpkin are checked, Chicken & brown rice is unchecked. On the right, a terrier portrait and Bowlfolk packaging above a buttery-yellow first-box summary. The action is Review first box.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [The Farmer’s Dog — Our Food](https://www.thefarmersdog.com/our-food) — Personalized fresh-food plans and recipe presentation.
- [The Farmer’s Dog — Onboarding](https://www.thefarmersdog.com/signup/me/GetStarted) — The public introduction to dog-profile, plan and checkout sequencing; later screens are an original synthesis.
- [Agrumea Farm](https://agrumeafarm.it/en) — Memorable original packaging, warm ingredient photography and restrained color.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — An expressive, confident food-brand voice.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — Clear selected controls and readable action hierarchy.
