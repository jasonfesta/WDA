# Recreation prompt

Create a 1746 × 901 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Tavora. Warm cream, vermilion-red condensed wordmark and big condensed display, honest overhead food photography, fine rules, dark green-black text. Keep the meal photographs as appetizing and textural as the reference. No bland app-card template.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F6F3EA, #D93119, #111C16. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: Restaurant Sunday Table; Harvest Bowl $15; House lemonade $5; quantity one each; subtotal $20; delivery $1.99; tax $1.80; total $23.79. Fictional address 123 Market St. Delivery 25–40 min. No automatic tip or extras.

Screen 1: Sunday Table
Entry: Open restaurant.
Selected state: Menu / Popular.
Visible content: Tavora compact brand header; a large food hero with the Harvest Bowl, $15, an Add button. Small second row House lemonade $5. Empty bag 0. Category rail Popular selected, Bowls, Drinks. Large readable title 'A good lunch starts here.'
Primary action: Choose Harvest Bowl.
Result: Bag starts empty.

Screen 2: Make it yours
Entry: Choose Harvest Bowl.
Selected state: Quinoa / Tahini / Add lemonade.
Visible content: Harvest Bowl food photograph, price $15; Base radio choices Quinoa selected, Brown rice unselected; Dressing Tahini selected, Herb yogurt unselected; 'Add house lemonade · $5' checked. Quantity 1. Optional note field. Header back arrow plus separate clear close button in safe right corner. Bottom 'Add to bag · $20'.
Primary action: Add to bag · $20.
Result: Bowl configuration + lemonade; 2 items.

Screen 3: Review your order
Entry: Add both items to bag.
Selected state: Delivery / Visa •••• 4242.
Visible content: Two compact line items Harvest Bowl $15, House lemonade $5; 123 Market St; 25–40 min; delivery selected; Visa •••• 4242; item subtotal $20, delivery $1.99, tax $1.80, total $23.79. One full-width red CTA 'Place order · $23.79'.
Primary action: Place order · $23.79.
Result: Payment reviewed.

Screen 4: Lunch is on its way
Entry: Place order successfully.
Selected state: Order status / Placed.
Visible content: Warm editorial food crop, order TV-1042, status 'Order confirmed'; step line Placed active, Preparing next, On the way next. 'Arrives in 25–40 min'. Receipt: 2 items, Paid $23.79, 123 Market St. Red 'Track order' and low-key 'View receipt'.
Primary action: Track order.
Result: Order placed; paid $23.79.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday. For the restaurant receipt, lemonade is a separate line item, not a duplicate bowl modifier.

# Inspiration

- [DoorDash restaurant menu](https://www.doordash.com/store/sweetgreen-new-york-52008/) — Restaurant metadata, category navigation, customization and a distinct order summary.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — Confident condensed red display typography and appetizing food scale.
- [Coffee Collective — Curated](https://curated.design/sites/s/4268/) — Quiet utility navigation and tactile photography.
- [Pizza Amici — CTA Gallery](https://www.cta.gallery/cta/pizza-amici) — One clear action against expressive typography; a visual reference, not a checkout reference.
