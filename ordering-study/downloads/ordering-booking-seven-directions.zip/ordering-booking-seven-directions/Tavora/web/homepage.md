# Recreation prompt

Create a complete 971 × 1619 px long-scroll desktop website page from navigation through footer. Every section retains a genuinely wide desktop layout.

Brand: Tavora. Warm cream, vermilion-red condensed wordmark and big condensed display, honest overhead food photography, fine rules, dark green-black text. Keep the meal photographs as appetizing and textural as the reference. No bland app-card template.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F6F3EA, #D93119, #111C16. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation: Tavora · Menu · Our kitchen · Delivery. Primary action: Order lunch.

Hero: oversized vermilion condensed headline beside a large warm photograph of a Harvest Bowl on a ceramic plate; compact 'Order lunch' button, delivery 25–40 min. Menu: four spacious columns with Harvest Bowl $15, Miso Salmon $19, Roast Chicken Plate $18, Green Goddess $16. Ordering preview: Harvest Bowl $15 plus House lemonade $5, subtotal 20 delivery 1.99 tax 1.80 total 23.79, button 'Review order'. Story: image of hands preparing seasonal vegetables to the left, heading 'Made for your midday' to the right and one short sentence about seasonal bowls. Process: Choose your plate / Make it yours / We’ll bring lunch. FAQ: 'Can I customize a bowl?' — 'Choose your base, dressing and extras.'; 'When will it arrive?' — 'Delivery estimates are shown before checkout.' Community strip: four original kitchen/ingredient/food photographs, heading 'From the kitchen'. Newsletter: 'Fresh from Tavora', email field, Subscribe. Footer wordmark tavora, Menu, Our kitchen, Delivery, Help, Privacy, Instagram.

Alternate full-width photography, image-left and image-right sections, product rows and editorial text. Include the complete community photo strip, newsletter signup and footer. Do not invent endorsements or statistics. Keep every section and the footer fully visible. No device shell or outer presentation margin.

# Inspiration

- [DoorDash restaurant menu](https://www.doordash.com/store/sweetgreen-new-york-52008/) — Restaurant metadata, category navigation, customization and a distinct order summary.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — Confident condensed red display typography and appetizing food scale.
- [Coffee Collective — Curated](https://curated.design/sites/s/4268/) — Quiet utility navigation and tactile photography.
- [Pizza Amici — CTA Gallery](https://www.cta.gallery/cta/pizza-amici) — One clear action against expressive typography; a visual reference, not a checkout reference.
