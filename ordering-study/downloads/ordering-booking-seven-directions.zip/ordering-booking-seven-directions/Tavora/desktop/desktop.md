# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Tavora. Warm cream, vermilion-red condensed wordmark and big condensed display, honest overhead food photography, fine rules, dark green-black text. Keep the meal photographs as appetizing and textural as the reference. No bland app-card template.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F6F3EA, #D93119, #111C16. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Horizontal brand navigation above a three-part desktop composition: narrow restaurant-information rail on the left, a two-column four-meal photographic menu in the middle, and a receipt-like bag on the right. Sunday Table is the restaurant. Show Harvest Bowl $15, Miso Salmon $19, Roast Chicken Plate $18 and Green Goddess $16. The bag has Harvest Bowl and House lemonade, one each. Headline: A good lunch starts here. Vermilion wordmark tavora; ample cream space and fine dividers.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [DoorDash restaurant menu](https://www.doordash.com/store/sweetgreen-new-york-52008/) — Restaurant metadata, category navigation, customization and a distinct order summary.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — Confident condensed red display typography and appetizing food scale.
- [Coffee Collective — Curated](https://curated.design/sites/s/4268/) — Quiet utility navigation and tactile photography.
- [Pizza Amici — CTA Gallery](https://www.cta.gallery/cta/pizza-amici) — One clear action against expressive typography; a visual reference, not a checkout reference.
