# Recreation prompt

Create a complete 727 × 2164 px responsive mobile website homepage. Use the paired website page in ../web/homepage.png as the composition and content reference, reflowed for a single narrow scrolling viewport. Keep the same brand, copy, products, photography style, prices and section order. This is the mobile website, with a compact browser address bar, a responsive site header and menu button.

Brand: Tavora. Warm cream, vermilion-red condensed wordmark and big condensed display, honest overhead food photography, fine rules, dark green-black text. Keep the meal photographs as appetizing and textural as the reference. No bland app-card template.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F6F3EA, #D93119, #111C16. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation links: Menu · Our kitchen · Delivery. Primary action: Order lunch.

Hero: oversized vermilion condensed headline beside a large warm photograph of a Harvest Bowl on a ceramic plate; compact 'Order lunch' button, delivery 25–40 min. Menu: four spacious columns with Harvest Bowl $15, Miso Salmon $19, Roast Chicken Plate $18, Green Goddess $16. Ordering preview: Harvest Bowl $15 plus House lemonade $5, subtotal 20 delivery 1.99 tax 1.80 total 23.79, button 'Review order'. Story: image of hands preparing seasonal vegetables to the left, heading 'Made for your midday' to the right and one short sentence about seasonal bowls. Process: Choose your plate / Make it yours / We’ll bring lunch. FAQ: 'Can I customize a bowl?' — 'Choose your base, dressing and extras.'; 'When will it arrive?' — 'Delivery estimates are shown before checkout.' Community strip: four original kitchen/ingredient/food photographs, heading 'From the kitchen'. Newsletter: 'Fresh from Tavora', email field, Subscribe. Footer wordmark tavora, Menu, Our kitchen, Delivery, Help, Privacy, Instagram.

Reflow wide layouts into one column; use two-column product grids only where labels remain comfortably readable. Keep purchase choices, prices, quantity and the primary action visible together. Stack forms and footer links naturally. Preserve full page height, complete newsletter and footer, original object proportions and readable typography. No native app tab bar, floating device frame, squeezed desktop page, clipping or outer presentation margins.

# Inspiration

- [DoorDash restaurant menu](https://www.doordash.com/store/sweetgreen-new-york-52008/) — Restaurant metadata, category navigation, customization and a distinct order summary.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — Confident condensed red display typography and appetizing food scale.
- [Coffee Collective — Curated](https://curated.design/sites/s/4268/) — Quiet utility navigation and tactile photography.
- [Pizza Amici — CTA Gallery](https://www.cta.gallery/cta/pizza-amici) — One clear action against expressive typography; a visual reference, not a checkout reference.
