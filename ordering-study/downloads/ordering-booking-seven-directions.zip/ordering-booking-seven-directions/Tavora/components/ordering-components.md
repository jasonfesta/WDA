# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Tavora. Warm cream, vermilion-red condensed wordmark and big condensed display, honest overhead food photography, fine rules, dark green-black text. Keep the meal photographs as appetizing and textural as the reference. No bland app-card template.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F6F3EA, #D93119, #111C16. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Restaurant item row with food thumbnail/name/$15/Add; customization panel with Base radio Quinoa selected, Dressing Tahini selected and checked lemonade $5; quantity minus/1/plus; optional note input. Delivery/address summary; two-line receipt subtotal 20 delivery 1.99 tax 1.80 total 23.79; red Place order button. Confirmation status timeline. Also show separate small disabled Continue button, active Add to bag $20, loading Placing order, inline error 'Choose a base' next to an unselected base group. Close button in its own 44 px target never overlapping title.

Persistent data: Restaurant Sunday Table; Harvest Bowl $15; House lemonade $5; quantity one each; subtotal $20; delivery $1.99; tax $1.80; total $23.79. Fictional address 123 Market St. Delivery 25–40 min. No automatic tip or extras.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday.

# Inspiration

- [DoorDash restaurant menu](https://www.doordash.com/store/sweetgreen-new-york-52008/) — Restaurant metadata, category navigation, customization and a distinct order summary.
- [CRAV — Landing Love](https://landing.love/sites/cravburgers/) — Confident condensed red display typography and appetizing food scale.
- [Coffee Collective — Curated](https://curated.design/sites/s/4268/) — Quiet utility navigation and tactile photography.
- [Pizza Amici — CTA Gallery](https://www.cta.gallery/cta/pizza-amici) — One clear action against expressive typography; a visual reference, not a checkout reference.
