# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Crookroot. Opinionated lavender canvas, electric lime selected states, tomato-orange ordering panels, massive natural condensed black display, eccentric imperfect real produce. Controlled punchy poster-like layout and readable UI.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 700, 800; [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 400, 500, 600, 800; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #C2ACF3, #FF5826, #D5FF2F, #201925. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Bold desktop commerce split: lavender left side with CROOKROOT wordmark, huge Odd looks. Great taste. headline and real misshapen carrots, tomato and eggplant. Orange ordering column at right. The mixed rescue box has Little 3 kg $16 and lime-selected Big 5 kg $24. One-off is selected and Weekly is unselected. Total $24. Dark Add box to bag button and delivery-next helper. No invented environmental savings totals.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Playful lavender/yellow commerce, bold typography and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Vivid produce photography and a decisive primary action.
- [Nicofrutta — Landing Love](https://www.landing.love/sites/nicofrutta/) — Large condensed farming headlines and expressive agricultural photography.
