# Recreation prompt

Create a complete 971 × 1619 px long-scroll desktop website page from navigation through footer. Every section retains a genuinely wide desktop layout.

Brand: Crookroot. Opinionated lavender canvas, electric lime selected states, tomato-orange ordering panels, massive natural condensed black display, eccentric imperfect real produce. Controlled punchy poster-like layout and readable UI.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 700, 800; [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 400, 500, 600, 800; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #C2ACF3, #FF5826, #D5FF2F, #201925. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation: Crookroot · Shop · How rescue works · Growers. Primary action: Choose your box.

Hero: huge condensed black headline on lavender with real gloriously crooked carrots, tomato and eggplant; lime 'Choose your box' button and orange ordering strip. Box choice section: Little 3 kg 16 unselected versus Big 5 kg 24 lime-selected; One-offselected Weeklyunselected; quantity 1; deliveryincluded; total 24; black 'Choose delivery · $24'. Story: bold orange section with farmer hands holding imperfect carrots on left, 'Good food doesn’t grow in straight lines' on right. Process: Pick your size / Choose a delivery day / Make something good. Pantry inspiration three large food-prep photos with short captions Roast it / Chop it / Share it, no invented environmental totals. FAQ 'What comes in the box?' — 'A changing mix of nearby growers’ seasonal produce.'; 'Is this a subscription?' — 'Choose a one-off box or select weekly delivery.' Four-image grower/produce/cooking photo strip with playful crops and no overlays over controls. Newsletter 'More good odd things', email/Subscribe. Complete footer CROOKROOT, Shop, Growers, Delivery, Help, Privacy, Instagram. Keep lavender,orange,lime bold blocks, never beige.

Alternate full-width photography, image-left and image-right sections, product rows and editorial text. Include the complete community photo strip, newsletter signup and footer. Do not invent endorsements or statistics. Keep every section and the footer fully visible. No device shell or outer presentation margin.

# Inspiration

- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Playful lavender/yellow commerce, bold typography and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Vivid produce photography and a decisive primary action.
- [Nicofrutta — Landing Love](https://www.landing.love/sites/nicofrutta/) — Large condensed farming headlines and expressive agricultural photography.
