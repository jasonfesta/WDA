# Recreation prompt

Create a 1747 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Crookroot. Opinionated lavender canvas, electric lime selected states, tomato-orange ordering panels, massive natural condensed black display, eccentric imperfect real produce. Controlled punchy poster-like layout and readable UI.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 700, 800; [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 400, 500, 600, 800; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #C2ACF3, #FF5826, #D5FF2F, #201925. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: Mixed rescue box; Big 5 kg$24 selected, Little 3 kg$16 unselected; one-off selected, weekly unselected. Quantity 1. Delivery 7Nov 2026 9 am–1 pm; deliveryincluded; tax 0; total$24. Address 123MarketSt; Visa 4242. No subscription created.

Screen 1: Odd looks. Great taste.
Entry: Open box picker.
Selected state: Big5kg / One-off.
Visible content: CROOKROOT chunky masthead; lavender ground, wonky tomato carrot and aubergine hero. Orange choice section Little 3 kg 16 unselected; Big 5 kg 24 lime selected. One-offselected, Weeklyunselected. CTA 'Choose delivery · $24'.
Primary action: Choose delivery · $24.
Result: One Bigbox selected.

Screen 2: A good day for odd veg
Entry: Choose delivery.
Selected state: 7Nov / 9am–1pm.
Visible content: Orange screen, lavender formfields. Address 123MarketSt; date 7Nov; window 9 am–1 pm limeactive,1–5 pmavailable. 'One-off order · Delivery included'. Summary Bigbox 5 kg 24. CTA 'Review box'.
Primary action: Review box.
Result: Deliverywindowselected.

Screen 3: Meet your next good meal
Entry: Review box.
Selected state: One-off / Visa4242.
Visible content: Lavenderwithboldtypography. Mixedrescuebox Big 5 kg,qty 1,$24; delivery 0; tax 0; total 24. One-off clearly stated.7Nov 9 am–1 pm 123MarketSt;Visa 4242. Darkbutton 'Place order · $24'.
Primary action: Place order · $24.
Result: One-off checkoutreviewed.

Screen 4: Odd veg. Excellent choice.
Entry: Place order successfully.
Selected state: Confirmed.
Visible content: Limebackground large friendlyblacktype and real misshapen carrotphoto. OrderCR-1042 confirmed; Bigbox 5 kg;7Nov 9 am–1 pm;Paid 24;One-off. 'No subscription'. DarkCTA 'Track my box'.
Primary action: Track my box.
Result: Boxconfirmed; nosubscription.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday.

# Inspiration

- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Playful lavender/yellow commerce, bold typography and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Vivid produce photography and a decisive primary action.
- [Nicofrutta — Landing Love](https://www.landing.love/sites/nicofrutta/) — Large condensed farming headlines and expressive agricultural photography.
