# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Crookroot. Opinionated lavender canvas, electric lime selected states, tomato-orange ordering panels, massive natural condensed black display, eccentric imperfect real produce. Controlled punchy poster-like layout and readable UI.

Typography: [Barlow Condensed](https://fonts.google.com/specimen/Barlow%20Condensed) — weights 700, 800; [Bricolage Grotesque](https://fonts.google.com/specimen/Bricolage%20Grotesque) — weights 400, 500, 600, 800; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #C2ACF3, #FF5826, #D5FF2F, #201925. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Little 3 kg 16 versusBig 5 kg 24 selector withBiglimeactive; One-offselected versusWeeklyunselected radiogroup; producecard withrealcrookedcarrot; qty 1; address 123MarketSt; delivery 9 am–1 pmlimeactive with 1–5 pmavailable; receipt 24+0+0=24; Placeorder 24 CTA and orderconfirmationcard. Include inlineerror 'Choose a box size', disabledContinue, loadingPlacingorder. Separate close target, vividflatcolors notgradients.

Persistent data: Mixed rescue box; Big 5 kg$24 selected, Little 3 kg$16 unselected; one-off selected, weekly unselected. Quantity 1. Delivery 7Nov 2026 9 am–1 pm; deliveryincluded; tax 0; total$24. Address 123MarketSt; Visa 4242. No subscription created.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday.

# Inspiration

- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Playful lavender/yellow commerce, bold typography and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Vivid produce photography and a decisive primary action.
- [Nicofrutta — Landing Love](https://www.landing.love/sites/nicofrutta/) — Large condensed farming headlines and expressive agricultural photography.
