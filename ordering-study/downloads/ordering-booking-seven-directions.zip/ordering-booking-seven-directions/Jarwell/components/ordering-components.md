# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Jarwell. Crisp white industrial grocery editorial, cobalt labels and rectangular controls, glass jars with brushed steel lids, big Space Grotesk and tiny monospaced utility. Gorgeous material photos, uncluttered alignment.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [IBM Plex Mono](https://fonts.google.com/specimen/IBM%20Plex%20Mono) — weights 400, 500; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F0F1ED, #263FDB, #14151B. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Cobalt-branded oats productrow; 500 g/1 kg segmentation with 1 kgactive; Returnablejar/Refillonlywithjaractive; qty 1 stepper; transparent breakdown oats 6 deposit 3 total 9; pickup-slot group 10–12 selected 12–2 available; Returning jars No selected; paymentrowVisa 4242; Placeorder 9 and confirmationpickupcard. Include depositexplainer, disabledContinue, loadingPlacingorder and inline error 'Choose a pickup time'. No refund credit yet.

Persistent data: Rolled oats 1 kg $6; one returnable jar refundabledeposit$3; quantity 1; pickupfree; tax 0; total$9. Pickup 7Nov 2026 10 am–12 pm at Market Street refill bar. No existing jars returned today; depositrefund happens only after return. Visa 4242.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday. Pickup is at Market Street refill bar, 123 Market Street, Brooklyn, NY 11201.

# Inspiration

- [Agronomy Work — Curated](https://curated.design/sites/s/4370/) — Open white composition, product metadata and large product photography; visual structure only.
- [Wastetide — CTA Gallery](https://www.cta.gallery/cta/wastetide) — Strong action hierarchy and direct, large-scale typography.
