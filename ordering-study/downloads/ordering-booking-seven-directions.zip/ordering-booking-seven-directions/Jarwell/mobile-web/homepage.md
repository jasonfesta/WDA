# Recreation prompt

Create a complete 725 × 2170 px responsive mobile website homepage. Use the paired website page in ../web/homepage.png as the composition and content reference, reflowed for a single narrow scrolling viewport. Keep the same brand, copy, products, photography style, prices and section order. This is the mobile website, with a compact browser address bar, a responsive site header and menu button.

Brand: Jarwell. Crisp white industrial grocery editorial, cobalt labels and rectangular controls, glass jars with brushed steel lids, big Space Grotesk and tiny monospaced utility. Gorgeous material photos, uncluttered alignment.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [IBM Plex Mono](https://fonts.google.com/specimen/IBM%20Plex%20Mono) — weights 400, 500; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F0F1ED, #263FDB, #14151B. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation links: Shop · How returns work · My jars. Primary action: Shop refills.

Hero: spectacular studio glass oats/coffee/lentil jars with brushed steel lids and cobalt Jarwell labels, giant black Space Grotesk headline on off-white; 'Shop refills' cobalt action. Pantry row: Rolled oats 1 kg 6, Whole-bean coffee 500 g 18, Chickpeas 1 kg 7; explicitly '+$3 refundable jar deposit each' below row. Focused featured product Rolled oats with 1 kgselected, Returnablejarselected, qty 1; product 6+deposit 3=total 9; 'Add refill · $9'. Return process in three roomy typographic sections: Fill your pantry / Keep your jar / Return for your deposit, original simple line icons and product details. Macro material story steel/glass left, 'Built for another round' right. Pickup banner 'Meet us at the refill bar', Market Street,123MarketStreet,BrooklynNY11201. FAQ 'When is my deposit refunded?' — 'After your jar is returned.'; 'Can I choose refill only?' — 'Bring your own suitable container to the refill bar.' Four-image studio/beans/oats/shop social strip titled 'Around the pantry'. Newsletter 'Good things, again', email/Subscribe. Complete Jarwell footer Shop, Returns, My jars, Pickup, Help, Privacy, Instagram.

Reflow wide layouts into one column; use two-column product grids only where labels remain comfortably readable. Keep purchase choices, prices, quantity and the primary action visible together. Stack forms and footer links naturally. Preserve full page height, complete newsletter and footer, original object proportions and readable typography. No native app tab bar, floating device frame, squeezed desktop page, clipping or outer presentation margins.

# Inspiration

- [Agronomy Work — Curated](https://curated.design/sites/s/4370/) — Open white composition, product metadata and large product photography; visual structure only.
- [Wastetide — CTA Gallery](https://www.cta.gallery/cta/wastetide) — Strong action hierarchy and direct, large-scale typography.
