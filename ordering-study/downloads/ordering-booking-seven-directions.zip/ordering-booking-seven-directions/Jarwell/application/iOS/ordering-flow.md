# Recreation prompt

Create a 1748 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Jarwell. Crisp white industrial grocery editorial, cobalt labels and rectangular controls, glass jars with brushed steel lids, big Space Grotesk and tiny monospaced utility. Gorgeous material photos, uncluttered alignment.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [IBM Plex Mono](https://fonts.google.com/specimen/IBM%20Plex%20Mono) — weights 400, 500; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F0F1ED, #263FDB, #14151B. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: Rolled oats 1 kg $6; one returnable jar refundabledeposit$3; quantity 1; pickupfree; tax 0; total$9. Pickup 7Nov 2026 10 am–12 pm at Market Street refill bar. No existing jars returned today; depositrefund happens only after return. Visa 4242.

Screen 1: Fill. Return. Repeat.
Entry: Open pantry product.
Selected state: 1kg / Returnable jar / qty1.
Visible content: Jarwell heading and gorgeous large glass oats jar with cobalt jarwell label. Rolled oats, 1 kg selected versus 500 g, returnablejar selected, qty 1. Product 6 deposit 3 total 9. CTA 'Add refill · $9'.
Primary action: Add refill · $9.
Result: One refill added.

Screen 2: Choose your pickup
Entry: Add refill.
Selected state: Market Street / 7Nov / 10–12.
Visible content: Market Street refill bar location; date 7Nov 2026;10 am–12 pm selected,12–2 pm unselected. 'Returning jars today?' No selected, Yes unselected. 'Your $3 deposit is refunded after this jar is returned.' Pickupfree. CTA 'Review refill'.
Primary action: Review refill.
Result: Pickup booked; no return credited.

Screen 3: Ready for another round
Entry: Review refill.
Selected state: Visa4242.
Visible content: One oats 1 kg jar thumbnail; quantity 1; Oats 6, refundable jar deposit 3, pickup 0, tax 0, total 9. Pickup 7Nov 10 am–12 pm MarketStreet. Visa 4242. CTA 'Place order · $9'.
Primary action: Place order · $9.
Result: Order reviewed.

Screen 4: See you at the refill bar
Entry: Place order successfully.
Selected state: Confirmed.
Visible content: Small cobalt-marked oats jar, receiptJW-1042; Paid$9; pickup 7Nov 10 am–12 pm MarketStreet;1 jar. Note 'Keep your jar. Bring it back for your $3 deposit.' CTA 'View pickup pass'; lower My jars 1.
Primary action: View pickup pass.
Result: Order paid;1jar recorded.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday.

# Inspiration

- [Agronomy Work — Curated](https://curated.design/sites/s/4370/) — Open white composition, product metadata and large product photography; visual structure only.
- [Wastetide — CTA Gallery](https://www.cta.gallery/cta/wastetide) — Strong action hierarchy and direct, large-scale typography.
