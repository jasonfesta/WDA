# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Jarwell. Crisp white industrial grocery editorial, cobalt labels and rectangular controls, glass jars with brushed steel lids, big Space Grotesk and tiny monospaced utility. Gorgeous material photos, uncluttered alignment.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [IBM Plex Mono](https://fonts.google.com/specimen/IBM%20Plex%20Mono) — weights 400, 500; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #F0F1ED, #263FDB, #14151B. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Off-white product-ordering desktop. Jarwell wordmark and quiet Shop / How returns work / My jars navigation; empty bag. Huge Fill. Return. Repeat. heading. Narrow pantry category rail; a large center photograph of glass oats, lentil and coffee jars with brushed steel lids and cobalt Jarwell labels; thumbnail detail strip beneath. Ordering controls on the right: Rolled oats, 1 kg selected, Returnable jar selected, quantity 1, $6 product + $3 refundable deposit = $9. Cobalt Add refill · $9 action.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [Agronomy Work — Curated](https://curated.design/sites/s/4370/) — Open white composition, product metadata and large product photography; visual structure only.
- [Wastetide — CTA Gallery](https://www.cta.gallery/cta/wastetide) — Strong action hierarchy and direct, large-scale typography.
