# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Noctair. Jet black, severe luxury fashion-house restraint, fine silver rules, ivory Bodoni editorial aircraft names and very clean Manrope controls. Photoreal black jet with beautiful slim rim lighting. No gold, no blue, no glossy rounded fintech cards. Lots of black negative space.

Typography: [Bodoni Moda](https://fonts.google.com/specimen/Bodoni%20Moda) — weights 400, 500; [Manrope](https://fonts.google.com/specimen/Manrope) — weights 400, 500, 600; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #080808, #F4F2EC, #666666. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Ultra-minimal jet-black desktop aircraft selection. Widely tracked NOCTAIR wordmark, quiet navigation, large New York — London route heading and one thin row of route/date/time/guest controls. A photoreal sleek black jet fills the left two thirds; the right column uses refined ivory serif text for Gulfstream G650ER and From $98,000. Aircraft is active in Journey / Aircraft / Review / Sent. One outlined Review charter request action. Whole aircraft, final quote on request. No gold or decorative gradients.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [Jesko Jets](https://jeskojets.com/) — Cinematic aviation materials, edited typography and sculptural photographic restraint.
- [Victor](https://www.flyvictor.com/en-gb/) — Public route, date, time, passenger and estimate controls; not live inventory.
- [VistaJet](https://www.vistajet.com/en-us/) — Inquiry-oriented charter presentation and a request-for-quote endpoint; a functional reference.
- [Quadplex 80 — Landing Love](https://www.landing.love/sites/quadplex80/) — Editorial scale, elegant serif typography and discreet inquiry controls.
- [Soho House — Curated](https://curated.design/sites/s/3088/) — Generous asymmetric space and quiet hospitality navigation. The black palette follows the selected concept’s luxury direction.
