# Recreation prompt

Create a 1747 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Noctair. Jet black, severe luxury fashion-house restraint, fine silver rules, ivory Bodoni editorial aircraft names and very clean Manrope controls. Photoreal black jet with beautiful slim rim lighting. No gold, no blue, no glossy rounded fintech cards. Lots of black negative space.

Typography: [Bodoni Moda](https://fonts.google.com/specimen/Bodoni%20Moda) — weights 400, 500; [Manrope](https://fonts.google.com/specimen/Manrope) — weights 400, 500, 600; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #080808, #F4F2EC, #666666. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: One-way TEB (New York) to FAB (London);12Nov 2026 at 10:00 local;6 guests; GulfstreamG650ER selected; up to 12 guests; indicative charter from$98,000, subject to availability and final quote. No payment charged. Fictional requestcontact Alex Morgan, alex@example.com.

Screen 1: Where next?
Entry: Start charter request.
Selected state: One way / Journey.
Visible content: NOCTAIR fine tracked masthead; black background. Origin New York TEB; destination London FAB; date 12Nov 2026; departure 10:00 local; guests 6. Understated silhouette wing photo bottom. CTA thin outlined 'Find aircraft'.
Primary action: Find aircraft.
Result: Itinerary specified.

Screen 2: Gulfstream G650ER
Entry: Find aircraft.
Selected state: Aircraft / G650ER.
Visible content: Dramatic black jet crop with polished silhouette filling middle. Tiny routeTEB→FAB 12Nov ·6 guests. 2 choices G650ER selected and Global 6000 unselected. 'Up to 12 guests', 'Nonstop · Ultra long range'. 'From $98,000' and 'Indicative charter'. CTA 'Review request'.
Primary action: Review request.
Result: G650ER selected.

Screen 3: Your charter request
Entry: Review request.
Selected state: Review.
Visible content: Quiet aligned facts TEB→FAB;12Nov 2026;10:00 local;6 guests;G650ER. Contact Alex Morgan and alex@example.com. 'Indicative price from $98,000'. 'No payment now. Final quote follows availability review.' Thin outlined CTA 'Send charter request'.
Primary action: Send charter request.
Result: Contact and itinerary reviewed.

Screen 4: Your request is with us
Entry: Send request successfully.
Selected state: Sent.
Visible content: NOCTAIR on black, subtle thin confirmation check, referenceNC-1042. TEB→FAB,12Nov,6 guests,G650ER. Status 'Awaiting your private quote'. 'No payment taken. This is not a confirmed booking.' CTA 'View request'; secondary Contact your advisor. Understated jet detail photograph.
Primary action: View request.
Result: Request sent; awaiting quote; no booking or charge.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday. The final charter state is awaiting a quote, with no charge or confirmed booking.

# Inspiration

- [Jesko Jets](https://jeskojets.com/) — Cinematic aviation materials, edited typography and sculptural photographic restraint.
- [Victor](https://www.flyvictor.com/en-gb/) — Public route, date, time, passenger and estimate controls; not live inventory.
- [VistaJet](https://www.vistajet.com/en-us/) — Inquiry-oriented charter presentation and a request-for-quote endpoint; a functional reference.
- [Quadplex 80 — Landing Love](https://www.landing.love/sites/quadplex80/) — Editorial scale, elegant serif typography and discreet inquiry controls.
- [Soho House — Curated](https://curated.design/sites/s/3088/) — Generous asymmetric space and quiet hospitality navigation. The black palette follows the selected concept’s luxury direction.
