# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Noctair. Jet black, severe luxury fashion-house restraint, fine silver rules, ivory Bodoni editorial aircraft names and very clean Manrope controls. Photoreal black jet with beautiful slim rim lighting. No gold, no blue, no glossy rounded fintech cards. Lots of black negative space.

Typography: [Bodoni Moda](https://fonts.google.com/specimen/Bodoni%20Moda) — weights 400, 500; [Manrope](https://fonts.google.com/specimen/Manrope) — weights 400, 500, 600; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #080808, #F4F2EC, #666666. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Black luxury charter components on black: route selectorTEB→FAB; one-wayselected; date 12Nov 2026; time 10:00 local; guest stepper 6; aircraft selection G650ER checked versus Global 6000; indicative from 98000 quote panel; editable contact fieldsAlexMorgan/alex@example.com; outlined Send charter request button; submitted confirmation Awaiting your private quote with No payment taken. One restrained inline validation 'Choose a departure date', disabled Find aircraft and loading Sending request. Native form fields use thinrules and generousblackspace, closeicon isolated wellclear of titles.

Persistent data: One-way TEB (New York) to FAB (London);12Nov 2026 at 10:00 local;6 guests; GulfstreamG650ER selected; up to 12 guests; indicative charter from$98,000, subject to availability and final quote. No payment charged. Fictional requestcontact Alex Morgan, alex@example.com.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday. Use alex@example.com where a sample contact email is needed.

# Inspiration

- [Jesko Jets](https://jeskojets.com/) — Cinematic aviation materials, edited typography and sculptural photographic restraint.
- [Victor](https://www.flyvictor.com/en-gb/) — Public route, date, time, passenger and estimate controls; not live inventory.
- [VistaJet](https://www.vistajet.com/en-us/) — Inquiry-oriented charter presentation and a request-for-quote endpoint; a functional reference.
- [Quadplex 80 — Landing Love](https://www.landing.love/sites/quadplex80/) — Editorial scale, elegant serif typography and discreet inquiry controls.
- [Soho House — Curated](https://curated.design/sites/s/3088/) — Generous asymmetric space and quiet hospitality navigation. The black palette follows the selected concept’s luxury direction.
