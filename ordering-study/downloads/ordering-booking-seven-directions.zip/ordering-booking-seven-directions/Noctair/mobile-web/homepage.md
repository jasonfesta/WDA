# Recreation prompt

Create a complete 726 × 2167 px responsive mobile website homepage. Use the paired website page in ../web/homepage.png as the composition and content reference, reflowed for a single narrow scrolling viewport. Keep the same brand, copy, products, photography style, prices and section order. This is the mobile website, with a compact browser address bar, a responsive site header and menu button.

Brand: Noctair. Jet black, severe luxury fashion-house restraint, fine silver rules, ivory Bodoni editorial aircraft names and very clean Manrope controls. Photoreal black jet with beautiful slim rim lighting. No gold, no blue, no glossy rounded fintech cards. Lots of black negative space.

Typography: [Bodoni Moda](https://fonts.google.com/specimen/Bodoni%20Moda) — weights 400, 500; [Manrope](https://fonts.google.com/specimen/Manrope) — weights 400, 500, 600; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #080808, #F4F2EC, #666666. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation links: Charter · The fleet · Private service. Primary action: Plan your journey.

Hero: almost-black full-bleed elegant hangar with a sleek black private jet and refined huge ivory serif headline, an understated outlined 'Plan your journey'. Thin rule route bar: New York TEB→London FAB;12Nov 2026;10:00 local;6 guests. Fleet section: oversized G650ER image right, disciplined editorial left 'Gulfstream G650ER', Up to 12 guests, indicative From 98000, finalquoteonrequest; two small understated aircraft choices G650ER selected and Global 6000 unselected. Service story: black leather cabin detail left with discreet text 'Every detail, considered' right. Request process: Your journey / Your aircraft / Your private quote, short lines. Clear quote CTA section 'Begin with a conversation' with from/to fields and Request a private quote; note 'Subject to availability. No payment is taken with a request.' FAQ 'Is this a confirmed fare?' — 'Your advisor confirms aircraft availability and a final quote.'; 'Can I request a specific aircraft?' — 'Share your preference when requesting a quote.' Four-image understated journal strip cabin, wing, leather, evening city; all black/gray. Newsletter 'Private notes', email/Subscribe, very quiet. Complete footer NOCTAIR, Charter, Fleet, Contact, Privacy, Instagram. Maintain enormous black breathing room; no gold, no bright color or generic card grid.

Reflow wide layouts into one column; use two-column product grids only where labels remain comfortably readable. Keep purchase choices, prices, quantity and the primary action visible together. Stack forms and footer links naturally. Preserve full page height, complete newsletter and footer, original object proportions and readable typography. No native app tab bar, floating device frame, squeezed desktop page, clipping or outer presentation margins.

# Inspiration

- [Jesko Jets](https://jeskojets.com/) — Cinematic aviation materials, edited typography and sculptural photographic restraint.
- [Victor](https://www.flyvictor.com/en-gb/) — Public route, date, time, passenger and estimate controls; not live inventory.
- [VistaJet](https://www.vistajet.com/en-us/) — Inquiry-oriented charter presentation and a request-for-quote endpoint; a functional reference.
- [Quadplex 80 — Landing Love](https://www.landing.love/sites/quadplex80/) — Editorial scale, elegant serif typography and discreet inquiry controls.
- [Soho House — Curated](https://curated.design/sites/s/3088/) — Generous asymmetric space and quiet hospitality navigation. The black palette follows the selected concept’s luxury direction.
