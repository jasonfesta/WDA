# Recreation prompt

Create a 1747 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Verdra. Electric cobalt navigation and buttons, warm white surfaces, substantial dark navy grotesk typography, honest market produce photography, airy fine dividers, simple full-width store rows.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #124AEF, #FAF9F5, #101636. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: Shop Harvest Market; Sourdough loaf $8; Tomatoes 1 lb $5; Eggs 12 pack $7; one of each, 3 items subtotal $20. Delivery $2.99; total $22.99; tax $0.00. Selected delivery 7 Nov 2026, 4–6 pm. Replacement preference 'Ask me first'. Fictional 123 Market St. Visa ••••4242.

Screen 1: Harvest Market
Entry: Open Harvest Market.
Selected state: Shop / All.
Visible content: Verdra brand and small address, punchy 'Fresh from your neighborhood.' produce banner, 3 clear rows Sourdough loaf $8, Tomatoes 1 lb $5, Eggs 12 pack $7; each quantity 1 and small food thumbnail. Basket 3. Persistent cobalt 'Review basket · $20'.
Primary action: Review basket · $20.
Result: 3 items selected.

Screen 2: Your delivery
Entry: Review basket.
Selected state: 7 Nov / 4–6 pm / Ask me first.
Visible content: Saved address 123 Market St with Edit; choose window rows 2–4 pm unavailable, 4–6 pm selected $2.99, 6–8 pm available $2.99. Replacement choice Ask me first selected, Refund unavailable items unselected. Summary 3 items $20. CTA 'Continue to review'.
Primary action: Continue to review.
Result: Delivery slot and substitutions saved.

Screen 3: Everything in order
Entry: Continue to review.
Selected state: Visa ••••4242.
Visible content: Three rows loaf 8 tomatoes 5 eggs 7 with quantity 1 each; 7 Nov 4–6 pm; Ask me first; Visa ••••4242. Subtotal 20, Delivery 2.99, Tax 0.00, Total 22.99. CTA 'Place order · $22.99'.
Primary action: Place order · $22.99.
Result: Checkout reviewed.

Screen 4: Your shop is booked
Entry: Place order successfully.
Selected state: Order status / Confirmed.
Visible content: Verdra-branded paper grocery bag and beautiful produce on white. Order VD-1042; 'Confirmed'; '7 Nov · 4–6 pm'; 3 items; Paid $22.99; 123 Market St. Progress Confirmed active, Shopping next, Delivering next. CTA 'Track delivery'.
Primary action: Track delivery.
Result: 3-item order confirmed.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday.

# Inspiration

- [Instacart store selection](https://www.instacart.com/store/?categoryFilter=homeTabForYou) — Location, delivery-window selection, store browsing and grocery categories.
- [Bud — Navbar Gallery](https://www.navbar.gallery/navbar/bud) — Compact navigation, consistent icons and a clear active destination.
- [Agrumea Farm](https://agrumeafarm.it/en) — Ingredient photography and a disciplined packaging palette; discovered through Landing Love.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — The website preview’s heading hierarchy, fine borders, tabs and primary-action contrast.
