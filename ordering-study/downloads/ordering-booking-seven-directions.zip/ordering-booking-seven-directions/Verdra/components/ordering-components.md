# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Verdra. Electric cobalt navigation and buttons, warm white surfaces, substantial dark navy grotesk typography, honest market produce photography, airy fine dividers, simple full-width store rows.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #124AEF, #FAF9F5, #101636. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Cobalt brand/navigation; 3-item shopping row set each quantity 1; search field and All active category chip; time-slot group with 2–4 pm disabled, 4–6 pm selected $2.99 and 6–8 pm unselected; replacement radios Ask me first selected; saved address row Edit; order summary subtotal 20 delivery 2.99 tax 0 total 22.99; Place order button and confirmation delivery card. Include inline validation 'Choose a delivery window', disabled Continue and loading Placing order. Every product row airy, no nested cards.

Persistent data: Shop Harvest Market; Sourdough loaf $8; Tomatoes 1 lb $5; Eggs 12 pack $7; one of each, 3 items subtotal $20. Delivery $2.99; total $22.99; tax $0.00. Selected delivery 7 Nov 2026, 4–6 pm. Replacement preference 'Ask me first'. Fictional 123 Market St. Visa ••••4242.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday.

# Inspiration

- [Instacart store selection](https://www.instacart.com/store/?categoryFilter=homeTabForYou) — Location, delivery-window selection, store browsing and grocery categories.
- [Bud — Navbar Gallery](https://www.navbar.gallery/navbar/bud) — Compact navigation, consistent icons and a clear active destination.
- [Agrumea Farm](https://agrumeafarm.it/en) — Ingredient photography and a disciplined packaging palette; discovered through Landing Love.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — The website preview’s heading hierarchy, fine borders, tabs and primary-action contrast.
