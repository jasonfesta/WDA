# Recreation prompt

Create a complete 971 × 1619 px long-scroll desktop website page from navigation through footer. Every section retains a genuinely wide desktop layout.

Brand: Verdra. Electric cobalt navigation and buttons, warm white surfaces, substantial dark navy grotesk typography, honest market produce photography, airy fine dividers, simple full-width store rows.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #124AEF, #FAF9F5, #101636. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation: Verdra · Shop · Our growers · How delivery works. Primary action: Shop the neighborhood.

Hero: large navy headline on warm white left, abundant citrus, fresh radishes, artisan bread and a Verdra paper grocery bag on right; cobalt 'Shop the neighborhood' button. Browse: three horizontal store entries Harvest Market, Good Pantry, Orchard & Vine, distinct original market photos, small delivery metadata. Product row: Sourdough loaf $8, Tomatoes 1 lb $5, Eggs 12 pack $7 with clear plus actions; small basket 3 items 20, delivery 2.99 total 22.99. Story section with farm produce portrait right and text 'Closer to the people who grow it' left. Process: Choose your groceries / Pick a delivery window / Tell us about replacements. FAQ: 'What if an item is unavailable?' — 'Choose Ask me first or a refund before checkout.'; 'Can I pick a delivery time?' — 'Choose an available window before placing your order.' Community strip four growers/market/ingredients photographs, no claims or testimonials. Newsletter 'The neighborhood note', email and Subscribe. Complete footer verdra, Shop, Growers, Delivery, Help, Privacy, Instagram.

Alternate full-width photography, image-left and image-right sections, product rows and editorial text. Include the complete community photo strip, newsletter signup and footer. Do not invent endorsements or statistics. Keep every section and the footer fully visible. No device shell or outer presentation margin.

# Inspiration

- [Instacart store selection](https://www.instacart.com/store/?categoryFilter=homeTabForYou) — Location, delivery-window selection, store browsing and grocery categories.
- [Bud — Navbar Gallery](https://www.navbar.gallery/navbar/bud) — Compact navigation, consistent icons and a clear active destination.
- [Agrumea Farm](https://agrumeafarm.it/en) — Ingredient photography and a disciplined packaging palette; discovered through Landing Love.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — The website preview’s heading hierarchy, fine borders, tabs and primary-action contrast.
