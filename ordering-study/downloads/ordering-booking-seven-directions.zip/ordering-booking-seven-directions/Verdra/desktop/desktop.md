# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Verdra. Electric cobalt navigation and buttons, warm white surfaces, substantial dark navy grotesk typography, honest market produce photography, airy fine dividers, simple full-width store rows.

Typography: [Space Grotesk](https://fonts.google.com/specimen/Space%20Grotesk) — weights 400, 500, 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #124AEF, #FAF9F5, #101636. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

A narrow cobalt navigation rail with Verdra wordmark, Shop active, Buy again, Saved lists and Offers. A compact top search/address/time/basket row. Large produce still-life banner: Good things. Close to home. Below, three broad horizontal photographic store rows for Harvest Market ($2.99 delivery), Good Pantry ($3.99 delivery), and Orchard & Vine ($2.49 delivery), each with a Shop store action. Basket is empty in this entry screen. Keep the produce bag branded Verdra.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [Instacart store selection](https://www.instacart.com/store/?categoryFilter=homeTabForYou) — Location, delivery-window selection, store browsing and grocery categories.
- [Bud — Navbar Gallery](https://www.navbar.gallery/navbar/bud) — Compact navigation, consistent icons and a clear active destination.
- [Agrumea Farm](https://agrumeafarm.it/en) — Ingredient photography and a disciplined packaging palette; discovered through Landing Love.
- [Navattic — SaaSpo](https://saaspo.com/pages/navattic-landing-page-v2) — The website preview’s heading hierarchy, fine borders, tabs and primary-action contrast.
