# Recreation prompt

Create a complete 1536 × 1024 px desktop ordering interface.

Brand: Solmesa. Sun-yellow fullbleed, cobalt typographic poster energy, huge naturally condensed Antonio headlines, luscious overhead rooftop vegetable supper photography, lavender bookingfields, graphic sun symbol. Airy and confident.

Typography: [Antonio](https://fonts.google.com/specimen/Antonio) — weights 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #FFE43B, #1233AE, #E6D7EB. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Full-bleed sun-yellow desktop supper-booking poster. Solmesa masthead and cobalt navigation. Huge Dinner Above It All. headline left and beautifully lit overhead vegetables on a cobalt plate to the right. Lavender booking strip across the bottom: November harvest supper, 13 Nov 2026, 7:00 pm, 2 seats, $65 per person and $130 total. Four-stage Supper / Seats / Review / Confirmed progress with Seats active. Cobalt Review two seats button. Preserve ample yellow space and a simple sun symbol.

No outer presentation frame, browser chrome, captions or watermarks. Preserve the full rectangular screen with unclipped controls.

# Inspiration

- [Sandy Shore — Landing Love](https://www.landing.love/sites/sandyshore/) — Sunny editorial sections, generous space and a strong yellow color field.
- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Confident color, expressive commerce and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Tactile ingredient photography and a prominent conversion action.
