# Recreation prompt

Create a complete 972 × 1619 px long-scroll desktop website page from navigation through footer. Every section retains a genuinely wide desktop layout.

Brand: Solmesa. Sun-yellow fullbleed, cobalt typographic poster energy, huge naturally condensed Antonio headlines, luscious overhead rooftop vegetable supper photography, lavender bookingfields, graphic sun symbol. Airy and confident.

Typography: [Antonio](https://fonts.google.com/specimen/Antonio) — weights 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #FFE43B, #1233AE, #E6D7EB. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Navigation: Solmesa · Supper club · The roof · Calendar. Primary action: Find your seat.

Hero: very large cobalt naturally condensed headline on brilliant yellow, glorious overhead roasted vegetables on blue ceramic and sunlight on glass; 'Find your seat' cobalt action, simple graphic sun. Booking panel lavender: Novemberharvestsupper, Friday 13Nov 2026,7 pm,2 guests,65/person,total 130, feesandtaxincluded, 'Review two seats'. Menu story: three lush photographs roastedcarrots/herbs/seasonalsalad with clear captions and heading 'What’s growing becomes dinner'. Rooftop story: evening shared table photograph left and 'A table under open sky' right. Process: Choose your supper / Save your seats / Join us on the roof. Practical panel 'Friday, 13 November · 7:00 pm', Rooftop 18MarketSt; Vegetarianoptionavailable. FAQ 'Can you accommodate dietary preferences?' — 'Add your preference and an allergy note when booking.'; 'What is included?' — 'The seasonal supper, with fees and tax included in the shown price.' Four-image rooftop/kitchen/harvest/sharedtable strip, heading 'Up on the roof'. Newsletter 'A brighter kind of dinner', email/Subscribe. Cobalt footer with yellow Solmesa wordmark, Supperclub, Calendar, Theroof, Contact, Privacy, Instagram.

Alternate full-width photography, image-left and image-right sections, product rows and editorial text. Include the complete community photo strip, newsletter signup and footer. Do not invent endorsements or statistics. Keep every section and the footer fully visible. No device shell or outer presentation margin.

# Inspiration

- [Sandy Shore — Landing Love](https://www.landing.love/sites/sandyshore/) — Sunny editorial sections, generous space and a strong yellow color field.
- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Confident color, expressive commerce and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Tactile ingredient photography and a prominent conversion action.
