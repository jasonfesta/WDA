# Recreation prompt

Create a 1536 × 1024 px ordering-component composition. Show naturally proportioned reusable interface pieces for selection, configuration, review and confirmation, with generous separation between specimens.

Brand: Solmesa. Sun-yellow fullbleed, cobalt typographic poster energy, huge naturally condensed Antonio headlines, luscious overhead rooftop vegetable supper photography, lavender bookingfields, graphic sun symbol. Airy and confident.

Typography: [Antonio](https://fonts.google.com/specimen/Antonio) — weights 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #FFE43B, #1233AE, #E6D7EB. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Components: Supper eventcard 65/person; compact date 13Nov 2026 selector;7 pmselected and 8:30 pmsoldoutdisabled; gueststepper 2; Vegetarianchoice active; allergyinputNoneadded; receipt 2×65=130 feesandtaxincluded; Booktwoseats 130 button; confirmationticket 13Nov 7 pm 2 guests. Include inlineerror 'Select a date', disabledContinue, loadingBookingseats. Cobalt/yellow/lavender, allcloseiconsseparate and safe.

Persistent data: November harvest supper;13Nov 2026;7:00 pm;2 seats;$65/person; total$130; feesandtaxincluded. Rooftop 18MarketSt (fictional). GuestAlexMorgan;Visa 4242. Dietary selection Vegetarian; allergen note 'None added'.

Include distinct selected, unselected, disabled, loading, validation-error and success examples. Keep error examples separate from completed receipts. No overlapping close icons or clipped dialogs. Dates must use the correct weekday: 7 November 2026 is Saturday, and 13 November 2026 is Friday. Use alex@example.com where a sample contact email is needed.

# Inspiration

- [Sandy Shore — Landing Love](https://www.landing.love/sites/sandyshore/) — Sunny editorial sections, generous space and a strong yellow color field.
- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Confident color, expressive commerce and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Tactile ingredient photography and a prominent conversion action.
