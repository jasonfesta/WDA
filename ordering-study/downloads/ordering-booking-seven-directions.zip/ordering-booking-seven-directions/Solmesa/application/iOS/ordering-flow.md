# Recreation prompt

Create a 1748 × 900 px four-screen iOS application flow, arranged left to right in four equal-height upright cells. Full bleed, square outside corners, no gaps or device shells. Add consistent status bars and bottom home indicators. Every screen must be complete.

Brand: Solmesa. Sun-yellow fullbleed, cobalt typographic poster energy, huge naturally condensed Antonio headlines, luscious overhead rooftop vegetable supper photography, lavender bookingfields, graphic sun symbol. Airy and confident.

Typography: [Antonio](https://fonts.google.com/specimen/Antonio) — weights 600, 700; [DM Sans](https://fonts.google.com/specimen/DM%20Sans) — weights 400, 500, 600, 700; use Arial, Helvetica, sans-serif as the sans-serif fallback; Georgia, Times New Roman, serif as the serif fallback; and Courier New, monospace for utility text where used. Palette: #FFE43B, #1233AE, #E6D7EB. Keep natural letterforms and photographic proportions. All people, addresses, transaction data and commercial offers are illustrative design content. Use readable controls, generous spacing and a clear primary action.

Persistent data: November harvest supper;13Nov 2026;7:00 pm;2 seats;$65/person; total$130; feesandtaxincluded. Rooftop 18MarketSt (fictional). GuestAlexMorgan;Visa 4242. Dietary selection Vegetarian; allergen note 'None added'.

Screen 1: Dinner Above It All.
Entry: Open supper club.
Selected state: The supper.
Visible content: Solmesa masthead on yellow; dramatic bigcobalt headline, beautiful overhead roastedvegetables/blueplate; 'November harvest supper'; 'Seasonal plates. Rooftop-grown herbs.' '$65 / person'. CTA 'Choose your seats'.
Primary action: Choose your seats.
Result: Eventselected.

Screen 2: Make a night of it
Entry: Choose seats.
Selected state: 13Nov / 7pm / 2seats / Vegetarian.
Visible content: Yellow/cobaltwithlavenderform. Date 13Nov 2026 selected;7:00 pmselected,8:30 pmsoldout; seats stepper 2;dietaryVegetarianselected; allergynote'None added'. '2 × $65 = $130'. CTA 'Review two seats'.
Primary action: Review two seats.
Result: 2seatsandpreferencesselected.

Screen 3: Your place at the table
Entry: Review seats.
Selected state: Visa4242.
Visible content: Novemberharvestsupper;13Nov 7 pm;2 guests;Vegetarian;18MarketStrooftop. GuestAlexMorgan;Visa 4242. Seats 2×65,Feesandtaxincluded,Total 130. CobaltCTA 'Book two seats · $130'.
Primary action: Book two seats · $130.
Result: Bookingreviewed.

Screen 4: You’re on the guest list
Entry: Book seats successfully.
Selected state: Confirmed.
Visible content: Cobaltbackgroundwithyellowtypeandsunicon; lavender reservationticket SM-1042;13Nov 2026 7 pm;2 guests;Vegetarian;Paid 130;18MarketStrooftop. YellowCTA 'View booking'; Addtocalendar secondary. Elegantfoodphotodetail.
Primary action: View booking.
Result: 2seatspaidandconfirmed.

Use a focused sequential flow with appropriate back navigation. Close controls must have their own clear touch target. Preserve choices and amounts from selection through review and confirmation. All displayed 7 November 2026 dates are Saturday; 13 November 2026 is Friday.

# Inspiration

- [Sandy Shore — Landing Love](https://www.landing.love/sites/sandyshore/) — Sunny editorial sections, generous space and a strong yellow color field.
- [Bored Cow — Navbar Gallery](https://www.navbar.gallery/navbar/bored-cow) — Confident color, expressive commerce and clear navigation.
- [Northeast Tomato — CTA Gallery](https://www.cta.gallery/cta/northeasttomato) — Tactile ingredient photography and a prominent conversion action.
